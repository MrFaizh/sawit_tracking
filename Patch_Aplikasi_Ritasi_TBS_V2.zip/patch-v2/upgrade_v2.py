"""Jalankan sekali dari folder proyek V1: python upgrade_v2.py"""
from pathlib import Path
import ast,shutil,datetime,sys
root=Path(__file__).resolve().parent
if not (root/'app/main.py').exists():raise SystemExit('Ekstrak V1 terlebih dahulu; salin isi patch V2 ke folder yang berisi requirements.txt dan app/.')
if '# TBS_V2_INSTALLED' in (root/'app/main.py').read_text(encoding='utf-8'):raise SystemExit('Patch V2 sudah terpasang.')
changes={}
def read(name):return (root/name).read_text(encoding='utf-8')
def replace(s,old,new,name):
    if old not in s:raise SystemExit('Versi V1 tidak cocok pada '+name+'. Tidak ada berkas V1 yang diubah.')
    return s.replace(old,new)
v2_ast=ast.parse(read('app/v2.py'))
extra=next(ast.literal_eval(n.value) for n in v2_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXTRA_HEADERS' for t in n.targets))
s=read('app/core.py')
line=next(x for x in s.splitlines() if x.startswith('HEADERS='))
s=replace(s,line,line+'\nHEADERS += '+repr(extra),'headers')
s=replace(s,'    return out\ndef validate(',"    from .v2 import clean_extra\n    out.update(clean_extra(body))\n    return out\ndef validate(",'core.clean')
s=replace(s,"    return issues,{'netto1_hitung'", "    from .v2 import review_flags\n    issues.extend(review_flags(b))\n    return issues,{'netto1_hitung'",'core.validate')
changes['app/core.py']=s
s=read('app/main.py')
s=replace(s,'UploadFile, File, Depends','UploadFile, File, Depends, Form','main imports')
s=replace(s,'def scan(file:UploadFile=File(...),u=Depends(ready)):', 'def scan(file:UploadFile=File(...),trip_id:str=Form(\'\'),u=Depends(ready)):', 'scan signature')
s=replace(s,"    raw=file.file.read(8*1024*1024+1)","    from .v2 import trip_guard,photo_quality,bind_trip\n    try: trip=trip_guard(trip_id,u)\n    except ValueError as e: fail(str(e))\n    raw=file.file.read(8*1024*1024+1)",'trip guard')
s=replace(s,"    text=result.get('fullTextAnnotation',{}).get('text','')", "    result['tbs_quality']=photo_quality(raw)\n    text=result.get('fullTextAnnotation',{}).get('text','')",'quality')
s=replace(s,"parsed=parse_ocr(text)","parsed=__import__('app.v2',fromlist=['parse_ocr_v2']).parse_ocr_v2(result)",'geometry parser')
s=replace(s,"body.update(parsed)","body.update(parsed); body.update({'trip_id':trip_id,'trip_snapshot':json.loads(trip['payload'])})",'draft snapshot')
s=replace(s,"        audit(c,u['id'],'SCAN',rid)","        bind_trip(c,trip_id,rid,u)\n        audit(c,u['id'],'SCAN',rid)",'bind trip')
# Applique au submit et au review : le serveur reconstruit les champs sensibles.
s=replace(s,"    try: b=clean(payload.get('body',{}))", "    from .v2 import enrich_before_submit\n    try:\n        payload=enrich_before_submit(payload,r,u,officer_mode=u['role']!='DRIVER')\n        b=clean(payload.get('body',{}))",'enrichment')
s=replace(s,"        status='PERLU_REVIEW' if issues else 'MENUNGGU_OFFICER'", "        blocking=[x for x in issues if not x.startswith('V2_')]\n        status='PERLU_REVIEW' if blocking else 'MENUNGGU_OFFICER'",'status')
s=replace(s,"'LOCAL' if issues else 'PENDING'", "'LOCAL' if blocking else 'PENDING'",'sync state')
s=replace(s,"result=sync_record(rid) if not issues else", "result=sync_record(rid) if not blocking else",'sync condition')
s=replace(s,"not x.startswith(('Persen potongan','Pelat nota'))", "not x.startswith(('Persen potongan','Pelat nota','V2_'))",'fatal filter')
s+='\n# TBS_V2_INSTALLED\nfrom .v2 import install_routes\ninstall_routes(app)\n'
changes['app/main.py']=s
s=read('app/google_io.py')
s=replace(s,'            assert len(row)==len(HEADERS)',"            from .v2 import extra_sheet_values\n            row.extend(extra_sheet_values(r,b,drive))\n            assert len(row)==len(HEADERS)",'row extras')
s=replace(s,':AL{r["sheet_row"]}',':BF{r["sheet_row"]}','range')
changes['app/google_io.py']=s
s=read('app/index.html');s=replace(s,'</script></body>','</script><script src="/v2.js"></script></body>','v2 UI');changes['app/index.html']=s
s=read('bootstrap_google.py')
s=s.replace("'frozenRowCount':1","'frozenRowCount':1,'columnCount':58").replace("'title,gridProperties.frozenRowCount'","'title,gridProperties.frozenRowCount,gridProperties.columnCount'").replace('A1:AL1','A1:BF1')
changes['bootstrap_google.py']=s
for name,text in changes.items():
    if name.endswith('.py'):ast.parse(text)
backup=root/('backup_kode_sebelum_v2_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'));backup.mkdir()
for name,text in changes.items():
    target=backup/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target);(root/name).write_text(text,encoding='utf-8')
print('Patch kode selesai. Backup kode:',backup.name)
print('STOP: backup database+foto, lalu jalankan python setup_master_v2.py sebelum server dinyalakan.')

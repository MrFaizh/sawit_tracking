/* Extension UI V2, dimuat setelah script V1. */
'use strict';
let v2Ready=false;
const oldApiV2=api;
api=async function(path,method='GET',payload){
  if(method==='POST' && path==='/scan' && payload instanceof FormData){const s=document.getElementById('tripSelectV2');if(!s||!s.value)throw Error('Buat/pilih perjalanan asal TBS dahulu.');payload.append('trip_id',s.value)}
  if(method==='POST' && /\/(submit|review)$/.test(path) && payload){const reason=document.getElementById('manualReasonV2');payload.manual_reason=reason?reason.value:''}
  return oldApiV2(path,method,payload);
};
function elV2(tag,text){const e=document.createElement(tag);if(text)e.textContent=text;return e}
function selectV2(id,title){let label=elV2('label',title),s=elV2('select');s.id=id;s.style.width='100%';label.append(s);return label}
function fillV2(id,rows,key,label){let s=$(id);s.replaceChildren();let blank=elV2('option','Pilih…');blank.value='';s.append(blank);for(const r of rows){let o=elV2('option',r[label]);o.value=r[key];s.append(o)}}
async function optionsV2(){let d=await api('/v2/options');fillV2('pksV2',d.MASTER_PKS,'pks_id','nama_pks');fillV2('ownerV2',d.MASTER_PEMILIK,'pemilik_id','nama_pemilik');fillV2('armadaV2',d.MASTER_ARMADA,'kategori_id','nama_kategori')}
async function tripsV2(){let rows=await api('/v2/trips'),s=$('tripSelectV2');s.replaceChildren();let blank=elV2('option','Pilih perjalanan sebelum scan nota');blank.value='';s.append(blank);for(const r of rows){let o=elV2('option',r.created+' · '+r.payload.pemilik.nama_pemilik+' → '+r.payload.pks.nama_pks);o.value=r.id;s.append(o)}return rows}
function gpsV2(){return new Promise((resolve,reject)=>{if(!navigator.geolocation){reject(Error('GPS tidak tersedia'));return}navigator.geolocation.getCurrentPosition(p=>resolve({lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy,timestamp_ms:p.timestamp}),e=>reject(Error('GPS gagal/izin ditolak. Aktifkan lokasi dan gunakan HTTPS.')),{enableHighAccuracy:true,maximumAge:0,timeout:25000})})}
async function initV2(){
 if(v2Ready||!user||user.must_change)return;v2Ready=true;
 let box=elV2('section');box.id='originBoxV2';box.append(elV2('h2','1. Foto & GPS asal TBS — sebelum berangkat'));
 box.append(elV2('p','Di lokasi muat: pilih pemilik, armada dan PKS, pilih/ambil foto kebun atau muatan, lalu simpan dengan GPS. GPS menunjukkan posisi HP saat tombol ditekan, bukan lokasi masa lalu dari foto galeri.'));
 for(const x of [['ownerV2','Pemilik TBS'],['armadaV2','Kategori armada'],['pksV2','PKS tujuan']])box.append(selectV2(...x));
 let l=elV2('label','Keterangan lokasi asal / kebun / blok'),desc=elV2('input');desc.id='originDescV2';l.append(desc);box.append(l);
 l=elV2('label','Foto asal TBS');let f=elV2('input');f.id='originPhotoV2';f.type='file';f.accept='image/jpeg,image/png,image/webp';f.setAttribute('capture','environment');l.append(f);box.append(l);
 const save=elV2('button','Ambil GPS & simpan asal TBS'),reload=elV2('button','Muat ulang pilihan');box.append(save,reload);
 const status=elV2('p');status.id='gpsStatusV2';box.append(status);$('capture').before(box);show('originBoxV2',user.role==='DRIVER');
 const tripLabel=selectV2('tripSelectV2','2. Pilih perjalanan untuk nota timbang ini');$('photo').before(tripLabel);
 $('capture').querySelector('h2').textContent='3. Scan nota timbang di PKS';
 save.onclick=()=>busy(async()=>{let file=$('originPhotoV2').files[0];if(!file)throw Error('Foto asal TBS belum dipilih');for(const id of ['ownerV2','pksV2','armadaV2'])if(!$(id).value)throw Error('Lengkapi pemilik, kategori armada dan PKS tujuan');status.textContent='Mengambil lokasi HP…';const g=await gpsV2();status.textContent='GPS ±'+Math.round(g.accuracy)+' m. Menyimpan…';const form=new FormData();form.append('file',file);form.append('meta',JSON.stringify({...g,pks_id:$('pksV2').value,pemilik_id:$('ownerV2').value,kategori_id:$('armadaV2').value,asal_deskripsi:$('originDescV2').value}));const r=await api('/v2/trips','POST',form);await tripsV2();$('tripSelectV2').value=r.id;status.textContent=r.message;msg(r.message)});
 reload.onclick=()=>busy(async()=>{await optionsV2();await tripsV2()});
 if(user.role!=='DRIVER'){let idBox=elV2('section'),idBtn=elV2('button','Lihat ID driver untuk pengisian master'),idOut=elV2('pre');idBtn.onclick=()=>busy(async()=>{idOut.textContent=JSON.stringify(await api('/v2/admin/driver-ids'),null,2)});idBox.append(idBtn,idOut);$('list').parentElement.before(idBox)}
 if(user.role==='DRIVER'){try{await optionsV2();await tripsV2()}catch(e){msg(e.message)}}
 let label=elV2('label','Alasan kolom diisi/dikoreksi manual atau foto kurang jelas (min. 15 karakter)'),text=elV2('textarea');text.id='manualReasonV2';text.rows=3;text.placeholder='Contoh: Nomor nota tidak terbaca OCR; disalin dari nota asli setelah diperiksa.';label.append(text);$('reasonLabel').before(label);
 let retakeBox=elV2('div');retakeBox.id='retakeBoxV2';let ri=elV2('input');ri.type='file';ri.accept='image/jpeg,image/png,image/webp';ri.setAttribute('capture','environment');ri.id='retakeFileV2';let rb=elV2('button','Foto ulang nota & baca OCR lagi');rb.type='button';rb.onclick=()=>busy(async()=>{let f=$('retakeFileV2').files[0];if(!f)throw Error('Pilih foto nota baru dahulu');let form=new FormData();form.append('file',f);let r=await api('/v2/records/'+active.id+'/retake','POST',form);await load();openRecord(all.find(x=>x.id===r.id));msg(r.message)});retakeBox.append(ri,rb);$('ocrText').parentElement.after(retakeBox);
 let info=elV2('div');info.id='tripInfoV2';$('ocrText').parentElement.before(info);
}
const oldOpenV2=openRecord;
openRecord=function(r){oldOpenV2(r);if($('retakeBoxV2'))show('retakeBoxV2',user.role==='DRIVER'&&['DRAFT','PERLU_REVIEW'].includes(r.status));let area=$('tripInfoV2');if(!area)return;area.replaceChildren();const t=r.body.trip_snapshot;
 if(t){let p=elV2('p','Pemilik: '+t.pemilik.nama_pemilik+' | Armada: '+t.armada.nama_kategori+' | Tujuan: '+t.pks.nama_pks+' | Asal: '+t.asal_deskripsi+' | GPS: '+t.gps.lat+', '+t.gps.lon+' ±'+t.gps.accuracy+' m');area.append(p);let img=elV2('img');img.src='/api/v2/records/'+r.id+'/origin';img.alt='Foto asal TBS';area.append(img);$('dataForm').elements.pabrik.value=t.pks.nama_pks;$('dataForm').elements.pabrik.disabled=true}
 let quality=r.ocr.raw?.tbs_quality?.warning;if(quality)area.append(elV2('p',quality+' — foto ulang diutamakan.'));
 let sources=r.body.field_sources;if(sources){let pre=elV2('pre',Object.entries(sources).map(([k,v])=>k+': '+v.source).join('\n'));area.append(pre)}
 $('manualReasonV2').value=r.body.manual_reason||'';
};
let timerV2=setInterval(()=>{if(user&&!user.must_change){clearInterval(timerV2);initV2().catch(e=>msg(e.message))}},300);

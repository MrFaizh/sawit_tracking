"""Extension V2: master terfilter, perjalanan asal TBS, GPS, dan jejak koreksi OCR."""
import os,json,uuid,time,math,io,hashlib
from pathlib import Path
from datetime import datetime
from fastapi import Depends,UploadFile,File,Form
from fastapi.responses import FileResponse
from PIL import Image,ImageOps,ImageFilter,ImageStat
from .core import db,now,parse_ocr,NUMS,TEXT
EXTRA_HEADERS=['Trip_ID','Pemilik_TBS_ID','Pemilik_TBS_Nama','Kategori_Armada','PKS_Tujuan_ID','PKS_Tujuan_Nama','PKS_Tujuan_Alamat','PKS_Tujuan_Lat','PKS_Tujuan_Lon','Asal_TBS_Deskripsi','Asal_Lat','Asal_Lon','GPS_Akurasi_M','GPS_Diambil_UTC','Foto_Asal_Server_WIB','Foto_Asal_Drive_URL','Foto_Asal_SHA256','Sumber_Field_OCR_JSON','Alasan_Input_Manual','Peringatan_Kualitas_Foto']
MASTER_HEADERS={
'MASTER_PKS':['pks_id','nama_pks','alamat','latitude','longitude','supplier_id','driver_id','aktif'],
'MASTER_PEMILIK':['pemilik_id','nama_pemilik','alamat','supplier_id','driver_id','aktif'],
'MASTER_ARMADA':['kategori_id','nama_kategori','supplier_id','driver_id','aktif']}
CATEGORIES={'MILIK_SENDIRI','KONTRAK','INCLUDE_HARGA_TBS'}
TRACKED=['no_nota','no_spb','pengemudi','no_polisi','masuk','keluar','bruto','tara','berondolan','netto1','potongan_persen','potongan_kg','netto2','kualitas']

def init_v2():
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS record_revisions_v2(id TEXT PRIMARY KEY,record_id TEXT,actor TEXT,created TEXT,photo TEXT,sha TEXT,body TEXT,ocr TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS trips_v2(id TEXT PRIMARY KEY,user_id TEXT,supplier TEXT,created TEXT,payload TEXT,photo TEXT,sha TEXT,record_id TEXT UNIQUE)')

def master_for(u):
    from .google_io import services
    _,s=services();sid=os.getenv('MASTER_SHEET_ID') or os.environ['GOOGLE_SHEET_ID']
    result=s.spreadsheets().values().batchGet(spreadsheetId=sid,ranges=[name+'!A1:Z' for name in MASTER_HEADERS],valueRenderOption='FORMATTED_VALUE').execute()
    out={}
    for tab,item in zip(MASTER_HEADERS,result.get('valueRanges',[])):
        rows=item.get('values',[])
        if not rows or rows[0][:len(MASTER_HEADERS[tab])]!=MASTER_HEADERS[tab]: raise ValueError('Header master salah: '+tab)
        allowed=[]
        for vals in rows[1:]:
            r=dict(zip(rows[0],vals+['']*max(0,len(rows[0])-len(vals))))
            # Selalu exact ID; tidak ada wildcard, prefix HP, atau filter UI saja.
            if r.get('aktif','').upper() not in ['TRUE','1','YA']: continue
            if r.get('supplier_id')!=u['supplier'] or r.get('driver_id')!=u['id']: continue
            if tab=='MASTER_ARMADA' and r.get('kategori_id') not in CATEGORIES: continue
            allowed.append(r)
        out[tab]=allowed
    if len(out)!=3: raise ValueError('Tab master belum lengkap')
    return out

def choose(options,tab,key,value):
    rows=[r for r in options[tab] if r.get(key)==value]
    if len(rows)!=1: raise ValueError('Pilihan tidak aktif/tidak berhak/duplikat pada '+tab)
    return rows[0]

def photo_quality(raw):
    im=Image.open(io.BytesIO(raw)).convert('L');im.thumbnail((1000,1000))
    edges=ImageStat.Stat(im.filter(ImageFilter.FIND_EDGES)).mean[0]
    contrast=ImageStat.Stat(im).stddev[0]
    # Hanya indikator UX; ambang belum dikalibrasi per kamera/layout nota.
    warn='Foto mungkin blur/kontras rendah; utamakan foto ulang' if edges<5 or contrast<15 else ''
    return {'edge_mean':round(edges,2),'contrast_std':round(contrast,2),'warning':warn,'method':'heuristic_unvalidated_v1'}

def parse_ocr_v2(result):
    """Conserve valeurs OCR; reconstruit les lignes par géométrie sans inventer les chiffres."""
    import statistics,re
    words=[]
    for page in result.get('fullTextAnnotation',{}).get('pages',[]):
        for block in page.get('blocks',[]):
            for para in block.get('paragraphs',[]):
                for w in para.get('words',[]):
                    vs=w.get('boundingBox',{}).get('vertices',[])
                    if len(vs)!=4:continue
                    pts=[(v.get('x',0),v.get('y',0)) for v in vs]
                    txt=''.join(z.get('text','') for z in w.get('symbols',[]))
                    dx=pts[1][0]-pts[0][0];dy=pts[1][1]-pts[0][1]
                    words.append({'text':txt,'x':sum(a for a,b in pts)/4,'y':sum(b for a,b in pts)/4,'h':max(1,math.hypot(pts[3][0]-pts[0][0],pts[3][1]-pts[0][1])),'angle':math.atan2(dy,dx),'confidence':w.get('confidence')})
    raw=result.get('fullTextAnnotation',{}).get('text','');lines=[]
    if words:
        angle=statistics.median(w['angle'] for w in words);co=math.cos(angle);si=math.sin(angle)
        for w in words:w['xx']=w['x']*co+w['y']*si;w['yy']=-w['x']*si+w['y']*co
        threshold=statistics.median(w['h'] for w in words)*0.6
        groups=[]
        for w in sorted(words,key=lambda v:v['yy']):
            if not groups or abs(w['yy']-statistics.mean(z['yy'] for z in groups[-1]))>threshold:groups.append([w])
            else:groups[-1].append(w)
        for group in groups:
            ordered=sorted(group,key=lambda v:v['xx']);confs=[w['confidence'] for w in ordered if isinstance(w['confidence'],(int,float))]
            lines.append({'text':' '.join(w['text'] for w in ordered),'min_word_confidence':min(confs) if confs else None})
    reconstructed='\n'.join(l['text'] for l in lines)
    def extract(text):
        fields=parse_ocr(text)
        for key,pattern in [('no_nota',r'(?im)^\s*(?:NO\.?|NOMOR\s+NOTA)\s*:\s*(\S+)'),('pengemudi',r'(?im)^\s*Pengemudi\s*:\s*(.+?)\s*$'),('transporter',r'(?im)^\s*Transporter\s*:\s*(.+?)\s*$'),('kualitas',r'(?im)^\s*Kualitas\s*:\s*(\S+)\s*$')]:
            m=re.search(pattern,text)
            if m:fields[key]=m.group(1).strip()
        return fields
    a=extract(raw);b=extract(reconstructed);conflicts={}
    for k,v in b.items():
        if k not in a:a[k]=v
        elif str(a[k]).upper()!=str(v).upper():conflicts[k]={'raw_parser':a.pop(k),'geometry_parser':v}
    result['tbs_lines']=lines;result['tbs_parse_conflicts']=conflicts
    return a

def normalize_origin(raw):
    if len(raw)>8*1024*1024: raise ValueError('Foto asal maksimal 8 MB')
    im=Image.open(io.BytesIO(raw));im.load();im=ImageOps.exif_transpose(im).convert('RGB')
    if min(im.size)<600: raise ValueError('Foto asal minimal sisi pendek 600 piksel')
    im.thumbnail((2600,2600));buf=io.BytesIO();im.save(buf,'JPEG',quality=93);return buf.getvalue()

def gps_values(meta,current=None):
    current=time.time() if current is None else current
    lat=float(meta['lat']);lon=float(meta['lon']);acc=float(meta['accuracy']);stamp=float(meta['timestamp_ms'])/1000
    if not all(math.isfinite(x) for x in [lat,lon,acc,stamp]): raise ValueError('GPS harus angka hingga')
    if not -90<=lat<=90 or not -180<=lon<=180 or acc<=0: raise ValueError('Koordinat/akurasi GPS tidak valid')
    if abs(current-stamp)>120: raise ValueError('GPS lebih dari 2 menit; ambil titik ulang di lokasi asal')
    if acc>float(os.getenv('GPS_MAX_ACCURACY_M','100')): raise ValueError('Akurasi GPS terlalu rendah; pindah area terbuka dan coba ulang')
    return {'lat':lat,'lon':lon,'accuracy':acc,'gps_utc':datetime.fromtimestamp(stamp,__import__('datetime').timezone.utc).isoformat()}

def trip_guard(trip_id,u):
    with db() as c:t=c.execute('SELECT * FROM trips_v2 WHERE id=? AND user_id=? AND supplier=?',(trip_id,u['id'],u['supplier'])).fetchone()
    if not t: raise ValueError('Pilih/buat perjalanan asal TBS milik sendiri terlebih dahulu')
    if t['record_id']: raise ValueError('Perjalanan sudah dipakai pada nota lain')
    age=(datetime.fromisoformat(now())-datetime.fromisoformat(t['created'])).total_seconds()
    if age>float(os.getenv('TRIP_MAX_HOURS','72'))*3600: raise ValueError('Perjalanan melewati batas umur; hubungi officer')
    return dict(t)

def bind_trip(c,trip_id,rid,u):
    changed=c.execute('UPDATE trips_v2 SET record_id=? WHERE id=? AND user_id=? AND supplier=? AND record_id IS NULL',(rid,trip_id,u['id'],u['supplier'])).rowcount
    if changed!=1: raise ValueError('Perjalanan sudah dipakai / tidak berhak')

def source_fields(ocr,b):
    parsed=ocr.get('parsed',{});out={}
    for k in TRACKED:
        a=parsed.get(k);v=b.get(k)
        try: equal=a is not None and (float(a)==float(v) if k in NUMS else str(a).strip().upper()==str(v).strip().upper())
        except Exception: equal=False
        out[k]={'source':'OCR_CONFIRMED' if equal else ('MANUAL_CORRECTION' if a is not None else 'MANUAL_NOT_EXTRACTED'),'ocr':a,'final':v}
    return out

def enrich_before_submit(payload,r,u,officer_mode=False):
    b=payload.get('body',{})
    with db() as c:
        t=c.execute('SELECT * FROM trips_v2 WHERE record_id=? AND user_id=?',(r['id'],r['user_id'])).fetchone()
        owner=c.execute('SELECT * FROM users WHERE id=?',(r['user_id'],)).fetchone()
    if not t or not owner: raise ValueError('Nota lama belum punya data asal V2. Buat perjalanan dan scan nota baru.')
    trip=json.loads(t['payload'])
    # Revalidasi hak master di server pada submit/review; jangan percaya ID/nama kiriman client.
    opts=master_for(dict(owner))
    choose(opts,'MASTER_PKS','pks_id',trip['pks']['pks_id'])
    choose(opts,'MASTER_PEMILIK','pemilik_id',trip['pemilik']['pemilik_id'])
    choose(opts,'MASTER_ARMADA','kategori_id',trip['armada']['kategori_id'])
    old=json.loads(r['body']);b['pabrik']=trip['pks']['nama_pks']
    ocr=json.loads(r['ocr']);sources=source_fields(ocr,b)
    manual=[k for k,v in sources.items() if v['source']!='OCR_CONFIRMED']
    reason=str(payload.get('manual_reason',b.get('manual_reason',old.get('manual_reason','')))).strip()[:2000]
    warning=ocr.get('raw',{}).get('tbs_quality',{}).get('warning','')
    if (manual or warning) and len(reason)<15: raise ValueError('Isi alasan input manual/foto kurang jelas minimal 15 karakter, atau foto ulang. Kolom: '+', '.join(manual))
    b.update({'trip_id':t['id'],'trip_snapshot':trip,'field_sources':sources,'manual_reason':reason,'quality_warning':warning})
    payload['body']=b
    return payload

def clean_extra(body):
    # Hanya dipanggil clean setelah enrich_before_submit membangun snapshot server.
    return {k:body[k] for k in ['trip_id','trip_snapshot','field_sources','manual_reason','quality_warning'] if k in body}

def review_flags(b):
    flags=[]
    if b.get('quality_warning'): flags.append('V2_FOTO: '+b['quality_warning'])
    manual=[k for k,v in b.get('field_sources',{}).items() if v['source']!='OCR_CONFIRMED']
    if manual: flags.append('V2_MANUAL: perlu officer cocokkan '+', '.join(manual))
    return flags

def extra_sheet_values(r,b,drive):
    from .google_io import file_put
    with db() as c:t=c.execute('SELECT * FROM trips_v2 WHERE id=? AND record_id=?',(b.get('trip_id',''),r['id'])).fetchone()
    if not t: return ['']*len(EXTRA_HEADERS) # kompatibilitas record V1 yang sudah disetujui
    q=json.loads(t['payload']);p=q['pks'];o=q['pemilik'];g=q['gps']
    fid=file_put(drive,r['id'],'origin',r['id']+'_asal.jpg',Path(t['photo']).read_bytes(),'image/jpeg')
    return [t['id'],o['pemilik_id'],o['nama_pemilik'],q['armada']['kategori_id'],p['pks_id'],p['nama_pks'],p.get('alamat',''),p.get('latitude',''),p.get('longitude',''),q['asal_deskripsi'],g['lat'],g['lon'],g['accuracy'],g['gps_utc'],t['created'],f'https://drive.google.com/file/d/{fid}/view',t['sha'],json.dumps(b.get('field_sources',{}),ensure_ascii=False),b.get('manual_reason',''),b.get('quality_warning','')]

def install_routes(app):
    from .main import ready,officer,record,accessible,fail
    from .core import audit
    init_v2()
    @app.get('/v2.js')
    def script():return FileResponse(Path(__file__).with_name('v2.js'),media_type='text/javascript')
    @app.get('/api/v2/options')
    def options(driver_id:str='',u=Depends(ready)):
        target=u
        if driver_id and driver_id!=u['id']:
            if u['role'] not in ['ADMIN','OFFICER']: fail('Tidak berhak',403)
            with db() as c:t=c.execute('SELECT * FROM users WHERE id=? AND role=\'DRIVER\' AND active=1',(driver_id,)).fetchone()
            if not t or (u['role']!='ADMIN' and t['supplier']!=u['supplier']):fail('Tidak ditemukan',404)
            target=dict(t)
        if target['role']!='DRIVER': return {k:[] for k in MASTER_HEADERS}
        try:return master_for(target)
        except Exception:fail('Master tidak tersedia. Hubungi admin; jangan ketik pilihan bebas.',503)
    @app.get('/api/v2/trips')
    def trips(u=Depends(ready)):
        with db() as c:rows=c.execute('SELECT * FROM trips_v2 WHERE user_id=? AND record_id IS NULL ORDER BY created DESC',(u['id'],)).fetchall()
        return [{'id':r['id'],'created':r['created'],'payload':json.loads(r['payload'])} for r in rows]
    @app.post('/api/v2/trips')
    def create_trip(meta:str=Form(...),file:UploadFile=File(...),u=Depends(ready)):
        if u['role']!='DRIVER':fail('Khusus driver',403)
        try:
            m=json.loads(meta);options=master_for(u)
            pks=choose(options,'MASTER_PKS','pks_id',m.get('pks_id'))
            try:
                plat=float(pks['latitude']);plon=float(pks['longitude'])
                if not math.isfinite(plat) or not math.isfinite(plon) or not -90<=plat<=90 or not -180<=plon<=180:raise ValueError()
            except Exception:raise ValueError('Koordinat PKS di master belum valid. Hubungi admin.')
            pemilik=choose(options,'MASTER_PEMILIK','pemilik_id',m.get('pemilik_id'))
            armada=choose(options,'MASTER_ARMADA','kategori_id',m.get('kategori_id'))
            description=str(m.get('asal_deskripsi','')).strip()[:1000]
            if len(description)<5:raise ValueError('Isi keterangan lokasi asal TBS')
            gps=gps_values(m);raw=normalize_origin(file.file.read(8*1024*1024+1))
        except ValueError as e:fail(str(e))
        except Exception:fail('Gagal membaca foto/GPS/master. Periksa data dan coba ulang.')
        tid=str(uuid.uuid4());folder=Path(os.getenv('TBS_UPLOADS','data/photos'))/'asal';folder.mkdir(parents=True,exist_ok=True);dest=folder/(tid+'.jpg');dest.write_bytes(raw)
        body={'pks':pks,'pemilik':pemilik,'armada':armada,'asal_deskripsi':description,'gps':gps}
        with db() as c:
            c.execute('INSERT INTO trips_v2 VALUES(?,?,?,?,?,?,?,NULL)',(tid,u['id'],u['supplier'],now(),json.dumps(body),str(dest),hashlib.sha256(raw).hexdigest()))
            audit(c,u['id'],'V2_CREATE_ORIGIN',tid,json.dumps(body))
        return {'id':tid,'payload':body,'message':'Asal TBS tersimpan. Pilih perjalanan ini saat scan nota PKS.'}
    @app.post('/api/v2/records/{rid}/retake')
    def retake(rid:str,file:UploadFile=File(...),u=Depends(ready)):
        from .google_io import ocr_image,SYNC_LOCK
        from .core import NUMS,TEXT
        if u['role']!='DRIVER':fail('Khusus driver pemilik',403)
        r=record(rid,u)
        if r['user_id']!=u['id'] or r['status'] not in ['DRAFT','PERLU_REVIEW']:fail('Hanya draft/nota ditahan yang bisa difoto ulang')
        try:
            raw=normalize_origin(file.file.read(8*1024*1024+1));result=ocr_image(raw)
            result['tbs_quality']=photo_quality(raw);parsed=parse_ocr_v2(result)
        except Exception:fail('Foto ulang/OCR gagal; data dan foto sebelumnya tetap tersimpan')
        old=json.loads(r['body']);body={k:'' for k in TEXT+NUMS};body.update({'harga':None});body.update(parsed)
        body.update({k:old[k] for k in ['trip_id','trip_snapshot'] if k in old})
        revision=str(uuid.uuid4());dest=Path(os.getenv('TBS_UPLOADS','data/photos'))/(rid+'_'+revision+'.jpg');dest.write_bytes(raw)
        with SYNC_LOCK,db() as c:
            c.execute('BEGIN IMMEDIATE')
            current=c.execute('SELECT status,revision FROM records WHERE id=?',(rid,)).fetchone()
            if current['status'] not in ['DRAFT','PERLU_REVIEW'] or current['revision']!=r['revision']:fail('Data berubah. Muat ulang sebelum foto ulang.',409)
            c.execute('INSERT INTO record_revisions_v2 VALUES(?,?,?,?,?,?,?,?)',(revision,rid,u['id'],now(),r['photo'],r['sha'],r['body'],r['ocr']))
            c.execute("UPDATE records SET body=?,ocr=?,photo=?,sha=?,issues='[]',status='DRAFT',sync_state='LOCAL',revision=revision+1 WHERE id=?",(json.dumps(body),json.dumps({'text':result.get('fullTextAnnotation',{}).get('text',''),'parsed':parsed,'raw':result}),str(dest),hashlib.sha256(raw).hexdigest(),rid))
            audit(c,u['id'],'V2_RETAKE',rid,revision)
        return {'ok':True,'id':rid,'message':'Foto nota diperbarui. Periksa ulang seluruh kolom.'}
    @app.get('/api/v2/records/{rid}/origin')
    def origin(rid:str,u=Depends(ready)):
        r=record(rid,u)
        with db() as c:t=c.execute('SELECT * FROM trips_v2 WHERE record_id=? AND user_id=?',(rid,r['user_id'])).fetchone()
        if not t:fail('Foto asal tidak ditemukan',404)
        return FileResponse(t['photo'],media_type='image/jpeg')
    @app.get('/api/v2/admin/driver-ids')
    def driver_ids(u=Depends(officer)):
        with db() as c:rows=c.execute("SELECT id,name,supplier,phone FROM users WHERE role='DRIVER' AND active=1").fetchall()
        return [dict(r) for r in rows if u['role']=='ADMIN' or r['supplier']==u['supplier']]

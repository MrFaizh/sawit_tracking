# REVISI V2 — asal TBS, foto GPS, pemilik, armada, PKS, master secure, OCR terkontrol

Paket ini PATCH untuk paket aplikasi RITASI TBS V1 yang sebelumnya diberikan. Bukan aplikasi standalone, bukan APK, belum terpasang di server/akun Google Anda. Kode baru disertakan; perintah di bawah dijalankan oleh admin Anda. Tidak ada perubahan akun Google yang dilakukan saat paket ini dibuat.

## A. Perubahan yang tersedia
1. Driver membuat PERJALANAN ASAL saat berada di lokasi muat, SEBELUM berangkat ke PKS.
2. Driver memilih pemilik TBS, kategori armada dan PKS tujuan dari master yang diizinkan untuk driver tersebut.
3. Ambil foto kebun/blok/muatan asal dan koordinat HP, akurasi GPS serta waktu pengambilan GPS. Aplikasi juga menyimpan waktu terima server.
4. Pilih perjalanan itu ketika memfoto nota timbang di PKS. Satu perjalanan terhubung satu nota, tidak dapat dipakai dua kali.
5. OCR mengisi data yang berhasil dibaca; merekonstruksi baris berdasarkan posisi kata untuk membantu layout nota dua kolom, bukan menebak angka yang hilang.
6. Driver meninjau foto dan hasil ekstraksi. Kolom yang tidak terbaca atau salah dapat diisi/dikoreksi manual dengan alasan. Jika foto kurang jelas, utamakan foto ulang; tombol foto ulang dan baca OCR lagi tersedia sebelum pengajuan.
7. Driver wajib mencentang telah mencocokkan seluruh angka dan identitas dengan nota. Validasi berjalan di server, bukan hanya di HP.
8. Submit yang valid mengirim foto nota, foto asal, JSON OCR/final dan baris transaksi ke Drive/Sheets dengan status MENUNGGU_OFFICER. Input manual ditandai untuk officer; bukan otomatis ditolak bila aritmetika/identitas lengkap.
9. Selisih aritmetika/identitas/tanggal masuk PERLU_REVIEW dan ditahan lokal sampai diperiksa officer, mengikuti mekanisme V1.
10. Hanya DISETUJUI masuk ritasi sah/rekap. Tidak ada perubahan otomatis pada kebijakan pembulatan 87 vs 90 pada nota contoh.

## B. Penting: aplikasi Android web, bukan native offline
Fitur yang berfungsi pada paket ini memakai UI browser HP Android + Cloud Vision OCR backend. Tidak menggunakan OCR native ML Kit dan tidak menyertakan APK. Scan memerlukan koneksi internet ke server/Google.

“OCR translate” di sini berarti mengekstrak angka/huruf menjadi field, bukan menerjemahkan bahasa atau mengubah isi asli nota. Teks mentah dan hasil OCR dipertahankan. AI tidak boleh menciptakan no nota/angka pada bagian tertutup atau blur. Tidak ada jaminan semua layout PKS berhasil diekstrak.

## C. Arsitektur master Google Sheets yang secure
Aplikasi membaca tab master menggunakan kredensial Google milik ADMIN di SERVER.
Driver TIDAK diberi link workbook master atau token Google, dan TIDAK memerlukan akun Google.
Dropdown berasal dari GET /api/v2/options dan hanya memuat baris:
- aktif = TRUE / 1 / YA;
- supplier_id persis sama dengan supplier akun;
- driver_id persis sama dengan ID internal akun.
Tidak ada wildcard (*), pencocokan prefix HP, filter tampilan saja, atau daftar seluruh supplier yang disembunyikan dengan JavaScript.

Server memeriksa ulang pilihan dari master ketika perjalanan dibuat, ketika nota diajukan, dan ketika officer memeriksa. Master yang tidak dapat dibaca -> gagal tertutup; driver tidak boleh memasukkan PKS/pemilik bebas untuk melewati pembatasan.
Satu baris per penugasan driver. Jika PKS yang sama boleh untuk tiga driver, buat tiga baris dengan pks_id sama tetapi driver_id berbeda. Jangan menggandakan kombinasi ID master + supplier_id + driver_id, karena dianggap ambigu.

MASTER_SHEET_ID opsional di .env untuk workbook master terpisah. Bila kosong, master berada pada workbook transaksi V1. Nilainya hanya ID spreadsheet, BUKAN link yang dibagikan ke driver. Gunakan akun Google admin yang memang memiliki hak akses ke workbook tersebut.
Google Sheets tidak memberi isolasi baris hanya karena baris disembunyikan atau filter view. Jangan membagikan workbook/folder gabungan langsung kepada driver/supplier lain. Isolasi per driver/per supplier berada pada backend aplikasi; admin Google tetap dapat melihat isi dokumen sesuai izin Google mereka.

## D. Format master worksheet
### MASTER_PKS
pks_id | nama_pks | alamat | latitude | longitude | supplier_id | driver_id | aktif
- Koordinat wajib valid saat dipilih. Isi desimal dengan titik, misalnya angka koordinat operasional yang benar; jangan menyalin koordinat contoh dari internet.
- Lokasi ini adalah LOKASI TUJUAN yang ditetapkan admin, bukan bukti GPS bahwa driver sudah tiba.
- Nama PKS tujuan mengisi field pabrik. Driver tetap harus memeriksa bahwa nota memang berasal dari PKS tersebut.

### MASTER_PEMILIK
pemilik_id | nama_pemilik | alamat | supplier_id | driver_id | aktif
- Menyimpan identitas pemilik TBS yang dipilih. Pemilihan bukan verifikasi legal kepemilikan kebun/TBS.
- Tidak memuat NIK/KTP. Jika perlu dokumen pemilik, rancang izin dan retensi terpisah.

### MASTER_ARMADA
kategori_id | nama_kategori | supplier_id | driver_id | aktif
Nilai kategori_id yang diterima:
- MILIK_SENDIRI — Milik sendiri
- KONTRAK — Kontrak
- INCLUDE_HARGA_TBS — Include harga TBS
Kategori adalah klasifikasi operasional sesuai master supplier. Tidak otomatis menentukan pemilik kendaraan secara hukum, tarif angkut, upah driver, pajak atau pembayaran. INCLUDE_HARGA_TBS tidak menjumlahkan ongkos angkut lagi; kebijakan akuntansi/tarif belum diotomasi.

Driver_ID adalah UUID internal dari akun, BUKAN nomor HP. Di dashboard officer/admin terdapat tombol “Lihat ID driver untuk pengisian master”; officer hanya mendapat daftar supplier-nya. Salin UUID tersebut ke tabel master. Supplier_ID mengikuti nilai pada pendaftaran akun V1.
Template Excel yang disertakan memuat contoh NONAKTIF (FALSE), bukan penugasan nyata. Jangan mengaktifkan placeholder.

## E. GPS dan foto asal: batasan kepercayaan
- GPS browser memerlukan HTTPS dan izin lokasi pengguna (localhost dapat menjadi pengecualian untuk uji komputer).
- Tombol “Ambil GPS & simpan” membaca lokasi HP SAAT TOMBOL DITEKAN. Itu BUKAN ekstraksi koordinat historis foto galeri dan bukan pelacakan perjalanan terus-menerus.
- Pakai foto baru saat di kebun/lokasi muat. Jangan mengambil GPS di PKS kemudian menganggapnya lokasi asal.
- Default akurasi yang diterima <=100 meter dan timestamp GPS tidak lebih dari 120 detik dari server; dapat disesuaikan GPS_MAX_ACCURACY_M.
- Default perjalanan dapat dipakai untuk scan nota dalam 72 jam; ubah TRIP_MAX_HOURS bila operasi memerlukan kebijakan lain.
- Aplikasi menyimpan lat/lon, akurasi, waktu GPS UTC, waktu terima server WIB, hash JPEG foto asal, serta hubungan trip–driver–nota.
- Foto asal disimpan bersama metadata terstruktur, BUKAN watermark yang dianggap bukti hukum. Koordinat tidak disisipkan sebagai EXIF yang dijamin asli.
- Lokasi dari perangkat dapat dipalsukan; kamera browser tidak menjamin foto baru (pilihan galeri bergantung perangkat). Belum ada anti-mock-location, device attestation, bukti di lokasi, face verification, atau verifikasi asal kebun secara independen.
- Koordinat dan foto asal termasuk data sensitif operasional. Ambil lokasi sekali saat muat dengan izin; tidak ada background tracking. Terapkan retensi, pembatasan akses, dan persetujuan penggunaan.

## F. OCR dan input manual
Sumber setiap field penting disimpan sebagai:
- OCR_CONFIRMED: nilai final sama dengan field yang berhasil diekstrak OCR; tetap butuh konfirmasi manusia, bukan jaminan benar.
- MANUAL_CORRECTION: OCR menghasilkan nilai, driver/officer memperbaikinya.
- MANUAL_NOT_EXTRACTED: field tidak berhasil diekstrak, lalu diisi manusia.

Penting: foto tajam pun kadang tidak terbaca karena layout/label/tulisan tangan; input manual diperbolehkan dengan alasan, tidak hanya karena blur. Form tidak akan memaksa driver menerima OCR yang salah.

Deteksi kualitas adalah HEURISTIK tepi/kontras, bukan model blur terkalibrasi dan bukan skor keyakinan field. Peringatan dapat salah. Nilai confidence kata dari Vision (jika tersedia) disimpan pada rekonstruksi baris, tetapi tidak digunakan sebagai jaminan kebenaran angka.
Jika pembacaan parser teks dan parser geometri bertentangan, field dihapus dari auto-fill dan konfliknya disimpan untuk pemeriksaan manual.

Tombol foto ulang tersedia untuk DRIVER pada DRAFT/PERLU_REVIEW sebelum persetujuan. Foto, OCR dan form sebelumnya diarsipkan di tabel SQLite record_revisions_v2, kemudian OCR baru mengisi ulang form. Revisi lama belum diekspor otomatis ke Drive; audit lokal harus dicadangkan.
Driver tetap wajib mengisi alasan minimal 15 karakter untuk field manual atau peringatan foto. Officer melihat foto nota, foto asal, metadata, dan penanda manual sebelum approve. Tidak ada otomatisasi mengubah 12.040 menjadi 12,04 tanpa pemeriksaan format.

## G. Instalasi PATCH pada V1
1. STOP server V1. Backup konsisten SQLite, folder foto, .env, token.json dan kode. Jangan menyalin DB aktif secara sembarang tanpa WAL/SQLite backup API.
2. Selesaikan antrean V1 sebelum upgrade. Record V1 tanpa trip asal tidak bisa diajukan/diapprove melalui alur V2; tidak ada migrasi GPS retroaktif. Jangan membuat lokasi asal palsu untuk nota lama. Record V1 yang sudah disetujui tetap dapat dilihat/rekap dan disinkron dengan kolom V2 kosong.
3. Ekstrak isi paket PATCH ke direktori V1 yang sama dengan requirements.txt. Struktur setelah salin:

    upgrade_v2.py
    setup_master_v2.py
    app/main.py          <- V1 sudah ada
    app/core.py          <- V1 sudah ada
    app/google_io.py     <- V1 sudah ada
    app/index.html       <- V1 sudah ada
    app/v2.py            <- BARU dari patch
    app/v2.js            <- BARU dari patch
    tests/test_v2.py     <- BARU dari patch

4. Aktifkan virtual environment V1, lalu:

    python upgrade_v2.py
    python setup_master_v2.py

Script pertama memeriksa anchor versi V1, memvalidasi sintaks hasil dan membuat backup kode sebelum menulis. Jika versi tidak cocok, script berhenti tanpa mengubah berkas V1; perlukan penyesuaian patch, jangan hapus guard.
Script kedua meminta konfirmasi YA lalu memperluas TRANSAKSI ke 58 kolom (A:BF), mempertahankan 38 kolom lama, dan membuat tiga tab master bila belum ada. Ini perubahan online yang dijalankan admin Anda; tidak berjalan otomatis saat membuka aplikasi.

5. Isi master di workbook Google dengan ID driver/supplier yang benar dan aktifkan penugasan yang sah.
6. Opsional tambahkan .env:

    MASTER_SHEET_ID=
    GPS_MAX_ACCURACY_M=100
    TRIP_MAX_HOURS=72

7. Jalankan tetap SATU worker:

    uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1

Gunakan domain HTTPS dan COOKIE_SECURE=true untuk operasional HP.

Untuk instalasi BARU: ekstrak V1, salin patch, jalankan upgrade_v2.py, lalu jalankan bootstrap_google.py yang sudah dipatch, kemudian setup_master_v2.py. Jangan menjalankan bootstrap_google.py ulang untuk instalasi lama karena V1 bootstrap membuat workbook/folder baru.

Patch tidak mengubah ketentuan V1: satu proses, disk persisten, Google token privat, no wildcard CORS, dan jangan sort/sisip/hapus/append manual baris TRANSAKSI. Gunakan filter view/tab salinan.

## H. 20 kolom baru setelah AL
AM Trip_ID
AN Pemilik_TBS_ID
AO Pemilik_TBS_Nama
AP Kategori_Armada
AQ PKS_Tujuan_ID
AR PKS_Tujuan_Nama
AS PKS_Tujuan_Alamat
AT PKS_Tujuan_Lat
AU PKS_Tujuan_Lon
AV Asal_TBS_Deskripsi
AW Asal_Lat
AX Asal_Lon
AY GPS_Akurasi_M
AZ GPS_Diambil_UTC
BA Foto_Asal_Server_WIB
BB Foto_Asal_Drive_URL
BC Foto_Asal_SHA256
BD Sumber_Field_OCR_JSON
BE Alasan_Input_Manual
BF Peringatan_Kualitas_Foto

Tab baru REKAP_ASAL_PKS juga dibuat oleh setup untuk rekap otomatis per tanggal, supplier, ID/nama driver, ID/nama pemilik, kategori armada dan ID/nama PKS, dengan jumlah ritasi/netto/nilai yang disetujui.

Rekap V1 tetap memakai kolom lama: tanggal keluar + supplier + driver; hanya DISETUJUI. Foto nota dan asal tetap file privat Drive; preview di aplikasi memeriksa akses setiap permintaan.

## I. Pengujian dan batasan
13 kasus fungsi inti diperiksa secara offline saat pembuatan: GPS valid/lama/di luar rentang/NaN/akurasi buruk; master exact/tidak dikenal/duplikat; sumber OCR sama/berbeda/hilang; kategori; filter master driver+supplier+aktif tanpa wildcard. Pemeriksaan sintaks Python dan JavaScript lulus. Transformasi patch diuji pada fixture kontrak anchor V1 yang diperkecil, BUKAN pengujian end-to-end atas instalasi Anda.

Tes integrasi Google OAuth/master/Drive/Sheets, browser Android/GPS/kamera, otorisasi HTTP, konkurensi serta foto nota sebenarnya BELUM dilakukan. Tidak ada klaim siap produksi tanpa uji tersebut. Jalankan pytest pada proyek gabungan dan lakukan checklist berikut:
[ ] Driver A hanya melihat master yang ditugaskan ke ID-nya; manipulasi ID di request ditolak.
[ ] Driver B tidak dapat membuka foto nota maupun foto asal A lewat URL langsung.
[ ] Officer supplier A tidak bisa membuka transaksi supplier B.
[ ] GPS ditolak jika terlalu lama/akurasi buruk; izin lokasi tidak diberikan -> pesan gagal, bukan koordinat palsu.
[ ] Pemilik dan lokasi PKS snapshot tetap tercatat walau nama master berubah kemudian.
[ ] Satu trip tidak bisa dipakai dua nota.
[ ] Foto ulang tidak menghilangkan arsip revisi lokal dan harus diperiksa ulang.
[ ] Koreksi 1740 ke angka lain tercatat MANUAL_CORRECTION dan divalidasi ulang.
[ ] Selisih potongan nota contoh tetap memerlukan officer; tidak otomatis dibulatkan.
[ ] Putus koneksi Google, lalu retry; cek status sinkron/rekap seperti prosedur V1.

Belum termasuk: APK native, OCR offline ML Kit, GPS anti-palsu, geofence kedatangan, peta tracking, beberapa pemilik asal per satu muatan, ongkos angkut otomatis, atau dashboard edit master (master diedit admin di Google Sheets).

## J. Sumber teknis
Geolocation browser: https://developer.mozilla.org/en-US/docs/Web/API/Geolocation_API
Google Sheets membaca master: https://developers.google.com/workspace/sheets/api/guides/values
Cloud Vision OCR: https://docs.cloud.google.com/vision/docs/ocr
ML Kit native (bukan implementasi paket ini): https://developers.google.com/ml-kit/vision/text-recognition/v2/android

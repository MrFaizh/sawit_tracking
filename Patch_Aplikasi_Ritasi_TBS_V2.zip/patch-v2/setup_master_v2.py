"""Perubahan Google hanya terjadi saat Anda menjalankan script ini secara lokal."""
import os
from app.core import HEADERS
from app.v2 import MASTER_HEADERS
from app.google_io import services
if input('Server sudah STOP, DB/foto sudah BACKUP? Ketik YA untuk mengubah header dan menambah tab master: ')!='YA':raise SystemExit('Dibatalkan')
drive,sheets=services();sid=os.environ['GOOGLE_SHEET_ID'];master=os.getenv('MASTER_SHEET_ID') or sid
# Hanya tambahkan kolom setelah AL. Tidak menggeser urutan 38 kolom V1.
old=sheets.spreadsheets().values().get(spreadsheetId=sid,range='TRANSAKSI!1:1').execute().get('values',[[]])[0]
if old[:38]!=HEADERS[:38]:raise SystemExit('Header V1 tidak cocok; jangan migrasi otomatis')
if len(old)>38 and old!=HEADERS:raise SystemExit('Kolom tambahan berbeda; perlu migrasi manual')
info=sheets.spreadsheets().get(spreadsheetId=sid).execute()
p=next(x['properties'] for x in info['sheets'] if x['properties']['title']=='TRANSAKSI')
if p['gridProperties']['columnCount']<len(HEADERS):sheets.spreadsheets().batchUpdate(spreadsheetId=sid,body={'requests':[{'updateSheetProperties':{'properties':{'sheetId':p['sheetId'],'gridProperties':{'columnCount':len(HEADERS)}},'fields':'gridProperties.columnCount'}}]}).execute()
sheets.spreadsheets().values().update(spreadsheetId=sid,range='TRANSAKSI!A1:BF1',valueInputOption='RAW',body={'values':[HEADERS]}).execute()
info=sheets.spreadsheets().get(spreadsheetId=master).execute();names={x['properties']['title'] for x in info['sheets']}
for title,headers in MASTER_HEADERS.items():
    if title not in names:sheets.spreadsheets().batchUpdate(spreadsheetId=master,body={'requests':[{'addSheet':{'properties':{'title':title,'gridProperties':{'frozenRowCount':1}}}}]}).execute()
    existing=sheets.spreadsheets().values().get(spreadsheetId=master,range=title+'!A1:Z1').execute().get('values',[[]])[0]
    if existing and existing!=headers:raise SystemExit('Tab '+title+' sudah ada dengan header berbeda; tidak ditimpa')
    sheets.spreadsheets().values().update(spreadsheetId=master,range=title+'!A1',valueInputOption='RAW',body={'values':[headers]}).execute()
summary='REKAP_ASAL_PKS'
info=sheets.spreadsheets().get(spreadsheetId=sid).execute()
if summary not in {t['properties']['title'] for t in info['sheets']}:
    sheets.spreadsheets().batchUpdate(spreadsheetId=sid,body={'requests':[{'addSheet':{'properties':{'title':summary}}}]}).execute()
formula='=QUERY(TRANSAKSI!A:BF,"select C,D,E,F,AN,AO,AP,AQ,AR,count(A),sum(V),sum(AC) where AD = \'DISETUJUI\' group by C,D,E,F,AN,AO,AP,AQ,AR label count(A) \'Ritasi\', sum(V) \'Netto_Kg\', sum(AC) \'Nilai_Rp\'",1)'
sheets.spreadsheets().values().update(spreadsheetId=sid,range=summary+'!A1',valueInputOption='USER_ENTERED',body={'values':[[formula]]}).execute()
print('58 kolom transaksi dan tiga tab master siap. Isi master dengan supplier_id/driver_id persis dari sistem. Tidak ada akses wildcard.')

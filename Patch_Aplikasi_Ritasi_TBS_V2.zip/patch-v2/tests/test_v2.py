import time,pytest
from app.v2 import gps_values,choose,source_fields,CATEGORIES

def gps():return dict(lat=1.25,lon=101.25,accuracy=12,timestamp_ms=1700000000000)
def test_valid_gps():assert gps_values(gps(),1700000000)['accuracy']==12
def test_stale_gps():
    with pytest.raises(ValueError):gps_values(gps(),1700000200)
def test_invalid_coordinates():
    g=gps();g['lat']=91
    with pytest.raises(ValueError):gps_values(g,1700000000)
def test_gps_nan():
    g=gps();g['lat']=float('nan')
    with pytest.raises(ValueError):gps_values(g,1700000000)
def test_gps_inaccurate(monkeypatch):
    monkeypatch.setenv('GPS_MAX_ACCURACY_M','100');g=gps();g['accuracy']=101
    with pytest.raises(ValueError):gps_values(g,1700000000)
def test_master_exact():assert choose({'tab':[{'id':'PKS-01'}]},'tab','id','PKS-01')['id']=='PKS-01'
def test_master_unknown():
    with pytest.raises(ValueError):choose({'tab':[{'id':'PKS-01'}]},'tab','id','PKS-02')
def test_master_duplicate():
    with pytest.raises(ValueError):choose({'tab':[{'id':'X'},{'id':'X'}]},'tab','id','X')
def test_ocr_source_exact():
    r=source_fields({'parsed':{'netto1':1740}},dict(netto1=1740))
    assert r['netto1']['source']=='OCR_CONFIRMED'
def test_ocr_source_correction():
    r=source_fields({'parsed':{'netto1':1740}},dict(netto1=1748))
    assert r['netto1']['source']=='MANUAL_CORRECTION'
def test_ocr_missing():assert source_fields({'parsed':{}},{})['no_nota']['source']=='MANUAL_NOT_EXTRACTED'
def test_categories():assert CATEGORIES=={'MILIK_SENDIRI','KONTRAK','INCLUDE_HARGA_TBS'}

def test_server_master_filters_exact_driver_supplier_active_no_wildcard(monkeypatch):
    from app.v2 import master_for,MASTER_HEADERS
    from app import google_io
    fixture=[]
    for tab,heads in MASTER_HEADERS.items():
        rows=[]
        for did,sup,active in [('D1','S1','TRUE'),('D2','S1','TRUE'),('D1','S2','TRUE'),('D1','S1','FALSE'),('*','S1','TRUE')]:
            d={h:'x' for h in heads};d.update(driver_id=did,supplier_id=sup,aktif=active)
            if tab=='MASTER_ARMADA':d['kategori_id']='KONTRAK'
            rows.append([d[h] for h in heads])
        fixture.append({'values':[heads]+rows})
    class Fake:
        def spreadsheets(self):return self
        def values(self):return self
        def batchGet(self,**kwargs):return self
        def execute(self):return {'valueRanges':fixture}
    monkeypatch.setenv('GOOGLE_SHEET_ID','offline-test-sheet')
    monkeypatch.setattr(google_io,'services',lambda:(None,Fake()))
    out=master_for({'id':'D1','supplier':'S1'})
    assert all(len(v)==1 and v[0]['driver_id']=='D1' and v[0]['supplier_id']=='S1' for v in out.values())

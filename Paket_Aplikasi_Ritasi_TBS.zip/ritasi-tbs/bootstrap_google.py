"""Jalankan di komputer admin dengan browser, bukan di HP driver."""
from pathlib import Path
from dotenv import set_key
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from app.core import HEADERS
from app.google_io import SCOPES
if not Path('client_secret.json').exists(): raise SystemExit('Unduh OAuth client Desktop app dari Cloud Console sebagai client_secret.json')
if not Path('.env').exists(): Path('.env').write_text(Path('.env.example').read_text())
cred=InstalledAppFlow.from_client_secrets_file('client_secret.json',SCOPES).run_local_server(port=0,access_type='offline',prompt='consent')
Path('token.json').write_text(cred.to_json())
drive=build('drive','v3',credentials=cred); sheets=build('sheets','v4',credentials=cred)
folder=drive.files().create(body={'name':'RITASI_TBS_PRIVATE','mimeType':'application/vnd.google-apps.folder'},fields='id').execute()['id']
sid=drive.files().create(body={'name':'RITASI_TBS_ONLINE','mimeType':'application/vnd.google-apps.spreadsheet','parents':[folder]},fields='id').execute()['id']
info=sheets.spreadsheets().get(spreadsheetId=sid).execute(); first=info['sheets'][0]['properties']['sheetId']
sheets.spreadsheets().batchUpdate(spreadsheetId=sid,body={'requests':[{'updateSpreadsheetProperties':{'properties':{'locale':'en_US','timeZone':'Asia/Jakarta'},'fields':'locale,timeZone'}},{'updateSheetProperties':{'properties':{'sheetId':first,'title':'TRANSAKSI','gridProperties':{'frozenRowCount':1}},'fields':'title,gridProperties.frozenRowCount'}},{'addSheet':{'properties':{'title':'REKAP_HARIAN'}}},{'addSheet':{'properties':{'title':'KAMUS_DATA'}}}]}).execute()
sheets.spreadsheets().values().update(spreadsheetId=sid,range='TRANSAKSI!A1:AL1',valueInputOption='RAW',body={'values':[HEADERS]}).execute()
formula='=QUERY(TRANSAKSI!A:AL,"select C,D,E,F,count(A),sum(V),sum(AC) where AD = \'DISETUJUI\' group by C,D,E,F label count(A) \'Ritasi\', sum(V) \'Netto_Kg\', sum(AC) \'Nilai_Rp\'",1)'
sheets.spreadsheets().values().update(spreadsheetId=sid,range='REKAP_HARIAN!A1',valueInputOption='USER_ENTERED',body={'values':[[formula]]}).execute()
rows=[['Kolom','Keterangan'],['Tanggal_Ritasi','Tanggal keluar nota WIB, bukan tanggal upload'],['Status','MENUNGGU_OFFICER, DISETUJUI, DITOLAK; hanya DISETUJUI dihitung'],['Harga_Per_Kg','Snapshot harga saat officer memeriksa; bukan tarif otomatis'],['Berondolan_Kg','Disimpan terpisah; tidak otomatis ditambah/dikurang ke netto'],['Netto2_Hitung_Kg','Netto1 nota - potongan kg nota'],['Nilai_Rp','Netto2 nota x harga per kg; tanpa ongkos driver/pajak'],['Foto_Drive_URL','Foto yang diorientasi ulang/dikompresi; bukan berkas sumber mentah'],['Aturan','Jangan sort, hapus, sisip atau tambah baris tab TRANSAKSI. Buat filter view/tab salinan.'],['Akses','Google sheet dan folder hanya admin; officer memakai aplikasi terfilter supplier.']]
sheets.spreadsheets().values().update(spreadsheetId=sid,range='KAMUS_DATA!A1',valueInputOption='RAW',body={'values':rows}).execute()
set_key('.env','GOOGLE_SHEET_ID',sid);set_key('.env','GOOGLE_FOLDER_ID',folder)
print('Workbook & folder privat dibuat. Sheet ID:',sid,'Folder ID:',folder)

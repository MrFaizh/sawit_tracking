import os, json, sqlite3, hashlib, secrets, hmac, re
from datetime import datetime
from zoneinfo import ZoneInfo
from decimal import Decimal, InvalidOperation
from dotenv import load_dotenv
load_dotenv()
TZ=ZoneInfo('Asia/Jakarta')
HEADERS=['ID','Dibuat_WIB','Tanggal_Ritasi','Supplier_ID','Driver_ID','Nama_Driver','No_HP','No_Polisi','Pabrik','No_Nota','No_SPB','Transporter','Pengemudi_Nota','Masuk_WIB','Keluar_WIB','Bruto_Kg','Tara_Kg','Berondolan_Kg','Netto1_Nota_Kg','Potongan_Persen','Potongan_Nota_Kg','Netto2_Nota_Kg','Netto1_Hitung_Kg','Potongan_Hitung_Kg','Netto2_Hitung_Kg','Selisih_Potongan_Kg','Kualitas','Harga_Per_Kg','Nilai_Rp','Status','Temuan_Validasi','Alasan_Koreksi','Officer_ID','Diperiksa_WIB','Foto_Drive_URL','SHA256_Foto','OCR_JSON_Drive_URL','OCR_vs_Final_JSON']
def now(): return datetime.now(TZ).isoformat(timespec='seconds')
def db():
    p=os.getenv('TBS_DB','data/tbs.sqlite3'); os.makedirs(os.path.dirname(p) or '.',exist_ok=True)
    c=sqlite3.connect(p,timeout=30); c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL'); return c
def init():
    with db() as c:
        c.executescript("""
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,phone TEXT UNIQUE,name TEXT,role TEXT,supplier TEXT,plate TEXT,password TEXT,must_change INTEGER,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,user_id TEXT,expires REAL);
CREATE TABLE IF NOT EXISTS attempts(phone TEXT PRIMARY KEY,fails INTEGER,until_ts REAL);
CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,user_id TEXT,supplier TEXT,created TEXT,body TEXT,ocr TEXT,photo TEXT,sha TEXT,status TEXT,issues TEXT,reason TEXT,officer TEXT,reviewed TEXT,sheet_row INTEGER UNIQUE,photo_id TEXT,ocr_id TEXT,sync_state TEXT,sync_error TEXT,revision INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,ts TEXT,actor TEXT,action TEXT,record_id TEXT,detail TEXT);
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY,v INTEGER);
INSERT OR IGNORE INTO meta VALUES('next_row',2);
""")
def audit(c,actor,action,rid='',detail=''):
    c.execute('INSERT INTO audit(ts,actor,action,record_id,detail) VALUES(?,?,?,?,?)',(now(),actor,action,rid,detail))
def pw_hash(p):
    salt=secrets.token_bytes(16)
    key=hashlib.scrypt(p.encode(),salt=salt,n=16384,r=8,p=1,dklen=32)
    return salt.hex()+':'+key.hex()
def pw_check(p,stored):
    salt,key=stored.split(':')
    got=hashlib.scrypt(p.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1,dklen=32)
    return hmac.compare_digest(got.hex(),key)
def phone(v):
    x=re.sub(r'[^0-9]','',str(v)); x='62'+x[1:] if x.startswith('0') else x
    if not re.fullmatch(r'62[0-9]{8,13}',x): raise ValueError('Nomor HP Indonesia tidak valid')
    return x
def plate(v): return re.sub(r'[^A-Z0-9]','',str(v).upper())
NUMS=['bruto','tara','berondolan','netto1','potongan_persen','potongan_kg','netto2']
TEXT=['pabrik','no_nota','no_spb','transporter','pengemudi','no_polisi','masuk','keluar','kualitas']
def clean(body):
    out={k:str(body.get(k,'')).strip()[:180] for k in TEXT}
    out['no_polisi']=plate(out['no_polisi'])
    for k in NUMS+['harga']:
        v=body.get(k,'')
        if k=='harga' and (v=='' or v is None): out[k]=None; continue
        try:
            d=Decimal(str(v))
            if not d.is_finite() or d<0 or d>Decimal('1000000000'): raise ValueError()
            out[k]=float(d)
        except (InvalidOperation,ValueError,TypeError): raise ValueError('Angka tidak valid: '+k+'. Gunakan 1740, bukan 1.740 / 1,740.')
    return out
def validate(b,user_plate=None):
    issues=[]
    for k in TEXT:
        if not b.get(k): issues.append('Kosong: '+k)
    for k in ['masuk','keluar']:
        try:
            d=datetime.fromisoformat(b[k])
            if d.tzinfo is not None: raise ValueError()
        except Exception: issues.append('Tanggal/jam WIB tidak valid: '+k)
    try:
        if datetime.fromisoformat(b['keluar'])<datetime.fromisoformat(b['masuk']): issues.append('Jam keluar sebelum masuk')
    except Exception: pass
    D=lambda k:Decimal(str(b[k]))
    n1=D('bruto')-D('tara'); pot=D('netto1')*D('potongan_persen')/100
    n2=D('netto1')-D('potongan_kg')
    if n1<0: issues.append('Bruto lebih kecil daripada tara')
    if D('netto1')<=0 or D('netto2')<=0: issues.append('Netto wajib positif')
    if D('potongan_persen')>100: issues.append('Persen potongan lebih dari 100')
    if D('potongan_kg')>D('netto1'): issues.append('Potongan melebihi netto1')
    if abs(n1-D('netto1'))>Decimal('0.01'): issues.append('Bruto - tara tidak sama dengan netto1 nota')
    if abs(n2-D('netto2'))>Decimal('0.01'): issues.append('Netto1 - potongan kg tidak sama dengan netto2 nota')
    if abs(pot-D('potongan_kg'))>Decimal('0.01'): issues.append('Persen potongan tidak cocok dengan kg potongan; perlu kebijakan pembulatan tertulis')
    if user_plate and plate(b['no_polisi'])!=plate(user_plate): issues.append('Pelat nota berbeda dengan akun driver')
    return issues,{'netto1_hitung':float(n1),'potongan_hitung':float(pot),'netto2_hitung':float(n2),'selisih_potongan':float(D('potongan_kg')-pot)}
def parse_ocr(text):
    # Konservatif: ekstrak hanya label dan nilai pada baris sama. Kolom hilang wajib diperiksa manusia.
    out={}
    for k,label in [('bruto','Bruto'),('tara','Tara'),('berondolan','B[eo]rondolan'),('netto1',r'Netto\s*1'),('netto2',r'Netto\s*2'),('potongan_kg',r'Berat[., ]*Pot'),('potongan_persen','Potongan')]:
        pattern=r'(?im)^\s*'+label+r'[^\n:0-9]*(?::\s*)?([0-9][0-9.,]*)\s*$'
        m=re.search(pattern,text)
        if m:
            v=m.group(1)
            if k=='potongan_persen': v=v.replace(',','.')
            elif re.fullmatch(r'\d{1,3}([.,]\d{3})+',v): v=v.replace(',','').replace('.','')
            try: out[k]=float(v)
            except ValueError: pass
    m=re.search(r'\b([A-Z]{1,2})\s*([0-9]{4})\s*([A-Z]{2,3})\b',text.upper())
    if m: out['no_polisi']=''.join(m.groups())
    m=re.search(r'(?im)^\s*No\.?\s*SPB\s*:?\s*(\S+)\s*$',text)
    if m: out['no_spb']=m.group(1)
    dates=re.findall(r'(\d{2})[/-](\d{2})[/-](\d{4})\s+(\d{2}:\d{2}:\d{2})',text)
    for key,parts in zip(['masuk','keluar'],dates):
        day,mon,yr,t=parts; out[key]=f'{yr}-{mon}-{day}T{t}'
    return out

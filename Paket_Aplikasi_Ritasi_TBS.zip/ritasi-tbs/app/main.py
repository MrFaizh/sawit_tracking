import os, json, time, secrets, hashlib, uuid, io, threading
from pathlib import Path
from datetime import datetime
from decimal import Decimal
from PIL import Image, ImageOps, UnidentifiedImageError
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Depends
from fastapi.responses import FileResponse, Response
from .core import *
from .google_io import ocr_image, sync_record, SYNC_LOCK
from functools import wraps
def serialized(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        with SYNC_LOCK: return fn(*args,**kwargs)
    return wrapped
app=FastAPI(title='Ritasi TBS MVP')
init()
AUTH_LOCK=threading.Lock()
Image.MAX_IMAGE_PIXELS=25000000

def fail(message,code=400): raise HTTPException(code,message)
def who(req:Request):
    token=req.cookies.get('tbs_session','')
    with db() as c:
        row=c.execute('SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.hash=? AND s.expires>? AND u.active=1',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
    if not row: fail('Silakan login kembali',401)
    return dict(row)
def ready(u=Depends(who)):
    if u['must_change']: fail('Wajib mengganti sandi awal',403)
    return u
def officer(u=Depends(ready)):
    if u['role'] not in ['ADMIN','OFFICER']: fail('Khusus officer/admin',403)
    return u
def accessible(r,u): return u['role']=='ADMIN' or (u['role']=='OFFICER' and r['supplier']==u['supplier']) or (u['role']=='DRIVER' and r['user_id']==u['id'])
def record(rid,u):
    with db() as c: r=c.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone()
    if not r or not accessible(r,u): fail('Data tidak ditemukan',404)
    return dict(r)
def public(r):
    return {k:(json.loads(v) if k in ['body','ocr','issues'] else v) for k,v in r.items() if k not in ['photo']}
@app.middleware('http')
async def headers(req,call_next):
    # SameSite cookie + fetch-only header: permintaan lintas situs tidak diizinkan.
    if req.url.path.startswith('/api/') and req.method not in ['GET','HEAD'] and req.headers.get('X-TBS-Client')!='1':
        return Response('Forbidden',403)
    res=await call_next(req)
    res.headers['Cache-Control']='no-store'
    res.headers['X-Content-Type-Options']='nosniff'
    res.headers['X-Frame-Options']='DENY'
    res.headers['Referrer-Policy']='no-referrer'
    return res
@app.get('/')
def index(): return FileResponse(Path(__file__).with_name('index.html'))
@app.post('/api/login')
def login(body:dict,response:Response):
    try: hp=phone(body.get('phone',''))
    except ValueError as e: fail(str(e))
    password=str(body.get('password',''))
    if len(password)>128: fail('Sandi terlalu panjang')
    with AUTH_LOCK, db() as c:
        a=c.execute('SELECT * FROM attempts WHERE phone=?',(hp,)).fetchone()
        if a and a['until_ts']>time.time(): fail('Terlalu banyak percobaan. Tunggu 15 menit.',429)
        u=c.execute('SELECT * FROM users WHERE phone=? AND active=1',(hp,)).fetchone()
        if not u or not pw_check(password,u['password']):
            n=(a['fails'] if a and a['until_ts']==0 else 0)+1
            c.execute('INSERT OR REPLACE INTO attempts VALUES(?,?,?)',(hp,n,time.time()+900 if n>=5 else 0)); c.commit()
            fail('Nomor HP atau sandi salah',401)
        c.execute('DELETE FROM attempts WHERE phone=?',(hp,))
        token=secrets.token_urlsafe(32)
        c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),u['id'],time.time()+int(os.getenv('SESSION_HOURS','8'))*3600))
        audit(c,u['id'],'LOGIN')
    response.set_cookie('tbs_session',token,httponly=True,secure=os.getenv('COOKIE_SECURE','true').lower()=='true',samesite='strict',max_age=int(os.getenv('SESSION_HOURS','8'))*3600)
    return {'name':u['name'],'role':u['role'],'must_change':bool(u['must_change'])}
@app.get('/api/me')
def me(u=Depends(who)): return {k:u[k] for k in ['id','name','role','supplier','plate','must_change']}
@app.post('/api/logout')
def logout(req:Request,res:Response,u=Depends(who)):
    with db() as c: c.execute('DELETE FROM sessions WHERE hash=?',(hashlib.sha256(req.cookies.get('tbs_session','').encode()).hexdigest(),))
    res.delete_cookie('tbs_session'); return {'ok':True}
@app.post('/api/password')
def password(body:dict,u=Depends(who)):
    old=str(body.get('old','')); new=str(body.get('new',''))
    if not pw_check(old,u['password']): fail('Sandi lama salah')
    if not 10<=len(new)<=128 or new==old or plate(u['plate']) in plate(new) and u['plate']: fail('Sandi baru 10–128 karakter, berbeda dan jangan memuat nomor pelat')
    with db() as c:
        c.execute('UPDATE users SET password=?,must_change=0 WHERE id=?',(pw_hash(new),u['id']))
        c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],)); audit(c,u['id'],'PASSWORD_CHANGED')
    return {'ok':True,'message':'Sandi diganti; login kembali'}
@app.post('/api/scan')
def scan(file:UploadFile=File(...),u=Depends(ready)):
    if u['role']!='DRIVER': fail('Scan menggunakan akun DRIVER',403)
    raw=file.file.read(8*1024*1024+1)
    if len(raw)>8*1024*1024: fail('Foto maksimum 8 MB')
    try:
        im=Image.open(io.BytesIO(raw)); im.load()
        if min(im.size)<600: fail('Resolusi terlalu kecil; minimal sisi pendek 600 piksel')
        im=ImageOps.exif_transpose(im).convert('RGB'); im.thumbnail((2600,2600))
        out=io.BytesIO(); im.save(out,'JPEG',quality=93); raw=out.getvalue()
    except HTTPException: raise
    except Exception: fail('Foto tidak valid / terlalu besar; gunakan JPG, PNG atau WEBP')
    try: result=ocr_image(raw)
    except Exception: fail('OCR gagal. Periksa kunci API/koneksi atau foto, kemudian coba lagi.',502)
    text=result.get('fullTextAnnotation',{}).get('text','')
    parsed=parse_ocr(text); rid=str(uuid.uuid4()); path=Path(os.getenv('TBS_UPLOADS','data/photos'))
    path.mkdir(parents=True,exist_ok=True); dest=path/(rid+'.jpg'); dest.write_bytes(raw)
    body={k:'' for k in TEXT+NUMS}; body.update({'harga':None}); body.update(parsed)
    # Belum pernah dikirim ke Drive: draft hanya di penyimpanan server.
    with db() as c:
        c.execute('INSERT INTO records(id,user_id,supplier,created,body,ocr,photo,sha,status,issues,reason,officer,reviewed,sync_state,sync_error) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(rid,u['id'],u['supplier'],now(),json.dumps(body),json.dumps({'text':text,'parsed':parsed,'raw':result}),str(dest),hashlib.sha256(raw).hexdigest(),'DRAFT','[]','','','','LOCAL',''))
        audit(c,u['id'],'SCAN',rid)
    return {'id':rid,'body':body,'text':text}
@app.get('/api/records')
def records(u=Depends(ready)):
    with db() as c:
        rows=c.execute('SELECT * FROM records ORDER BY created DESC').fetchall()
    return [public(dict(r)) for r in rows if accessible(r,u)][:500]
@app.get('/api/records/{rid}/photo')
def photo(rid:str,u=Depends(ready)):
    r=record(rid,u); return FileResponse(r['photo'],media_type='image/jpeg')
def dup(c,rid,b,supplier):
    for r in c.execute("SELECT id,body FROM records WHERE id<>? AND supplier=? AND status IN ('MENUNGGU_OFFICER','PERLU_REVIEW','DISETUJUI')",(rid,supplier)):
        o=json.loads(r['body'])
        if o.get('no_nota','').upper()==b['no_nota'].upper() and o.get('pabrik','').upper()==b['pabrik'].upper(): return True
    return False
@app.post('/api/records/{rid}/submit')
@serialized
def submit(rid:str,payload:dict,u=Depends(ready)):
    r=record(rid,u)
    if u['role']!='DRIVER' or r['user_id']!=u['id']: fail('Khusus driver pemilik',403)
    if not payload.get('confirmed'): fail('Wajib mencocokkan seluruh kolom dengan foto')
    try: b=clean(payload.get('body',{}))
    except ValueError as e: fail(str(e))
    issues,_=validate(b,u['plate'])
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT status FROM records WHERE id=?',(rid,)).fetchone()[0]
        if current not in ['DRAFT','PERLU_REVIEW']: fail('Transaksi sudah dikirim')
        if dup(c,rid,b,r['supplier']): fail('Duplikat nomor nota + pabrik pada supplier ini')
        if c.execute("SELECT id FROM records WHERE sha=? AND supplier=? AND id<>? AND status IN ('MENUNGGU_OFFICER','PERLU_REVIEW','DISETUJUI')",(r['sha'],r['supplier'],rid)).fetchone(): fail('Foto sama sudah dipakai pada nota lain')
        status='PERLU_REVIEW' if issues else 'MENUNGGU_OFFICER'
        c.execute('UPDATE records SET body=?,issues=?,status=?,sync_state=?,revision=revision+1 WHERE id=?',(json.dumps(b),json.dumps(issues),status,'LOCAL' if issues else 'PENDING',rid))
        audit(c,u['id'],'DRIVER_SUBMIT',rid,json.dumps({'issues':issues,'body':b}))
    result=sync_record(rid) if not issues else {'ok':False,'message':'Ada selisih/data kosong. Ditahan lokal untuk officer; belum dikirim ke Google.'}
    return {'status':status,'issues':issues,'sync':result}
@app.post('/api/records/{rid}/review')
@serialized
def review(rid:str,payload:dict,u=Depends(officer)):
    r=record(rid,u)
    action=payload.get('action'); reason=str(payload.get('reason','')).strip()[:2000]
    if action not in ['APPROVE','REJECT']: fail('Aksi tidak valid')
    if r['status'] not in ['PERLU_REVIEW','MENUNGGU_OFFICER']: fail('Status bukan antrean pemeriksaan')
    try: b=clean(payload.get('body',{}))
    except ValueError as e: fail(str(e))
    with db() as c: owner=c.execute('SELECT plate FROM users WHERE id=?',(r['user_id'],)).fetchone()
    issues,_=validate(b,owner['plate'])
    before=json.loads(r['body']); changed=b!=before
    if action=='APPROVE':
        fatal=[x for x in issues if not x.startswith(('Persen potongan','Pelat nota'))]
        if fatal: fail('Perbaiki angka/tanggal sebelum disetujui: '+'; '.join(fatal))
        if any(not b[k] for k in TEXT): fail('Lengkapi semua identitas dan tanggal nota')
        for k in ['masuk','keluar']:
            try:
                dt=datetime.fromisoformat(b[k])
                if dt.tzinfo: raise ValueError()
            except Exception: fail('Tanggal/jam WIB belum valid')
        if (issues or changed or json.loads(r['issues'])) and len(reason)<15: fail('Koreksi/pengecualian wajib alasan minimal 15 karakter')
        if not payload.get('photo_checked'): fail('Officer wajib memeriksa foto dan angka satu per satu')
        if b['harga'] is None: fail('Isi harga/kg untuk persetujuan transaksi; boleh 0 bila memang tidak dinilai')
    elif len(reason)<15: fail('Alasan penolakan minimal 15 karakter')
    status='DISETUJUI' if action=='APPROVE' else 'DITOLAK'
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        state=c.execute('SELECT status,revision FROM records WHERE id=?',(rid,)).fetchone()
        if state['revision']!=payload.get('revision') or state['status'] not in ['PERLU_REVIEW','MENUNGGU_OFFICER']: fail('Data berubah. Muat ulang.',409)
        if action=='APPROVE' and dup(c,rid,b,r['supplier']): fail('Duplikat nota; jangan disetujui')
        c.execute('UPDATE records SET body=?,issues=?,reason=?,officer=?,reviewed=?,status=?,revision=revision+1,sync_state=? WHERE id=?',(json.dumps(b),json.dumps(issues),reason,u['id'],now(),status,'PENDING' if action=='APPROVE' else 'LOCAL',rid))
        audit(c,u['id'],action,rid,json.dumps({'before':before,'after':b,'issues':issues,'reason':reason},ensure_ascii=False))
    # Penolakan yang sebelumnya sudah tersinkron harus diperbarui agar tidak terlihat menunggu.
    if action=='REJECT' and r['sheet_row']:
        from .google_io import services
        try:
            _,s=services(); s.spreadsheets().values().update(spreadsheetId=os.environ['GOOGLE_SHEET_ID'],range=f'TRANSAKSI!AD{r["sheet_row"]}:AH{r["sheet_row"]}',valueInputOption='RAW',body={'values':[[status,json.dumps(issues),reason,u['id'],now()]]}).execute()
            with db() as c: c.execute("UPDATE records SET sync_state='SYNCED',sync_error='' WHERE id=?",(rid,))
        except Exception as e:
            with db() as c: c.execute("UPDATE records SET sync_state='ERROR',sync_error=? WHERE id=?",(str(e)[:500],rid))
    return {'status':status,'sync':sync_record(rid) if action=='APPROVE' else {'ok':True,'message':'Ditolak; tidak dihitung sebagai ritasi sah'}}
@app.post('/api/sync')
def sync(u=Depends(officer)):
    from .google_io import services
    with db() as c: rows=c.execute("SELECT * FROM records WHERE sync_state IN ('PENDING','ERROR')").fetchall()
    results=[]
    for row in rows:
        r=dict(row)
        if not accessible(r,u): continue
        if r['status'] in ['MENUNGGU_OFFICER','DISETUJUI']: results.append({'id':r['id'],**sync_record(r['id'])})
        elif r['status']=='DITOLAK' and r['sheet_row']:
            try:
                _,s=services(); s.spreadsheets().values().update(spreadsheetId=os.environ['GOOGLE_SHEET_ID'],range=f'TRANSAKSI!AD{r["sheet_row"]}:AH{r["sheet_row"]}',valueInputOption='RAW',body={'values':[['DITOLAK',r['issues'],r['reason'],r['officer'],r['reviewed']]]}).execute()
                with db() as c: c.execute("UPDATE records SET sync_state='SYNCED',sync_error='' WHERE id=?",(r['id'],))
                results.append({'id':r['id'],'ok':True})
            except Exception: results.append({'id':r['id'],'ok':False})
    return results
@app.get('/api/report')
def report(date:str='',u=Depends(ready)):
    date=date or datetime.now(TZ).date().isoformat(); groups={}
    with db() as c:
        rows=c.execute("SELECT r.*,u.name FROM records r JOIN users u ON u.id=r.user_id WHERE r.status='DISETUJUI'").fetchall()
    for row in rows:
        r=dict(row); b=json.loads(r['body'])
        if not accessible(r,u) or b['keluar'][:10]!=date: continue
        key=(r['supplier'],r['user_id'])
        g=groups.setdefault(key,{'tanggal':date,'supplier':r['supplier'],'driver':r['name'],'ritasi':0,'netto_kg':Decimal(0),'nilai_rp':Decimal(0)})
        g['ritasi']+=1; g['netto_kg']+=Decimal(str(b['netto2'])); g['nilai_rp']+=Decimal(str(b['netto2']))*Decimal(str(b['harga'] or 0))
    return [{**g,'netto_kg':float(g['netto_kg']),'nilai_rp':float(g['nilai_rp'].quantize(Decimal('0.01')))} for g in groups.values()]

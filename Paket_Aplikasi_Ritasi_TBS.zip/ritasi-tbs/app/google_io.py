import os, json, io, threading
import requests
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from .core import db, HEADERS, validate
SYNC_LOCK=threading.RLock()
SCOPES=['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/spreadsheets']
def services():
    cred=Credentials.from_authorized_user_file(os.getenv('GOOGLE_TOKEN_FILE','token.json'),SCOPES)
    return build('drive','v3',credentials=cred,cache_discovery=False),build('sheets','v4',credentials=cred,cache_discovery=False)
def ocr_image(raw):
    import base64
    key=os.getenv('VISION_API_KEY','')
    if not key: raise ValueError('VISION_API_KEY belum diisi. OCR belum aktif.')
    r=requests.post('https://vision.googleapis.com/v1/images:annotate',headers={'X-Goog-Api-Key':key},json={'requests':[{'image':{'content':base64.b64encode(raw).decode()},'features':[{'type':'DOCUMENT_TEXT_DETECTION'}],'imageContext':{'languageHints':['id']}}]},timeout=60)
    r.raise_for_status(); result=r.json()['responses'][0]
    if 'error' in result: raise ValueError('OCR gagal: '+result['error'].get('message','unknown'))
    return result

def file_put(drive,rid,kind,name,raw,mime):
    folder=os.environ['GOOGLE_FOLDER_ID']
    q=f"'{folder}' in parents and trashed=false and appProperties has {{ key='tbs_id' and value='{rid}' }} and appProperties has {{ key='kind' and value='{kind}' }}"
    found=drive.files().list(q=q,fields='files(id)',pageSize=10).execute().get('files',[])
    media=MediaIoBaseUpload(io.BytesIO(raw),mimetype=mime,resumable=False)
    if found:
        fid=found[0]['id']
        if kind=='ocr': drive.files().update(fileId=fid,media_body=media).execute()
        return fid
    return drive.files().create(body={'name':name,'parents':[folder],'appProperties':{'tbs_id':rid,'kind':kind}},media_body=media,fields='id').execute()['id']
def sync_record(rid):
    with SYNC_LOCK:
        try:
            with db() as c: r=dict(c.execute('SELECT * FROM records WHERE id=?',(rid,)).fetchone())
            if r['status'] not in ['MENUNGGU_OFFICER','DISETUJUI']: return {'ok':False,'message':'Belum lolos pemeriksaan; tidak dikirim ke Google'}
            drive,sheets=services(); b=json.loads(r['body']); oc=json.loads(r['ocr'])
            fid=file_put(drive,rid,'photo',rid+'.jpg',open(r['photo'],'rb').read(),'image/jpeg')
            payload={'ocr':oc,'final':b,'issues':json.loads(r['issues']),'reason':r['reason'],'status':r['status'],'reviewer':r['officer'],'reviewed':r['reviewed']}
            oid=file_put(drive,rid,'ocr',rid+'.json',json.dumps(payload,ensure_ascii=False).encode(),'application/json')
            with db() as c:
                u=dict(c.execute('SELECT * FROM users WHERE id=?',(r['user_id'],)).fetchone())
                if not r['sheet_row']:
                    c.execute('BEGIN IMMEDIATE')
                    n=c.execute("SELECT v FROM meta WHERE k='next_row'").fetchone()[0]
                    c.execute("UPDATE meta SET v=v+1 WHERE k='next_row'")
                    c.execute('UPDATE records SET sheet_row=? WHERE id=?',(n,rid)); r['sheet_row']=n
            _,calc=validate(b)
            diff={k:{'ocr':v,'final':b.get(k)} for k,v in oc.get('parsed',{}).items() if b.get(k)!=v}
            nilai=round(b['netto2']*b['harga'],2) if b['harga'] is not None else ''
            row=[rid,r['created'],b['keluar'][:10],r['supplier'],r['user_id'],u['name'],u['phone'],b['no_polisi'],b['pabrik'],b['no_nota'],b['no_spb'],b['transporter'],b['pengemudi'],b['masuk'],b['keluar'],b['bruto'],b['tara'],b['berondolan'],b['netto1'],b['potongan_persen'],b['potongan_kg'],b['netto2'],calc['netto1_hitung'],calc['potongan_hitung'],calc['netto2_hitung'],calc['selisih_potongan'],b['kualitas'],b['harga'] if b['harga'] is not None else '',nilai,r['status'],r['issues'],r['reason'],r['officer'],r['reviewed'],f'https://drive.google.com/file/d/{fid}/view',r['sha'],f'https://drive.google.com/file/d/{oid}/view',json.dumps(diff,ensure_ascii=False)]
            assert len(row)==len(HEADERS)
            info=sheets.spreadsheets().get(spreadsheetId=os.environ['GOOGLE_SHEET_ID'],fields='sheets(properties)').execute()
            tab=next(t['properties'] for t in info['sheets'] if t['properties']['title']=='TRANSAKSI')
            if r['sheet_row']>tab['gridProperties']['rowCount']:
                sheets.spreadsheets().batchUpdate(spreadsheetId=os.environ['GOOGLE_SHEET_ID'],body={'requests':[{'appendDimension':{'sheetId':tab['sheetId'],'dimension':'ROWS','length':1000}}]}).execute()
            # RAW mencegah formula injection dari teks nota.
            sheets.spreadsheets().values().update(spreadsheetId=os.environ['GOOGLE_SHEET_ID'],range=f'TRANSAKSI!A{r["sheet_row"]}:AL{r["sheet_row"]}',valueInputOption='RAW',body={'values':[row]}).execute()
            with db() as c: c.execute("UPDATE records SET photo_id=?,ocr_id=?,sync_state='SYNCED',sync_error='' WHERE id=?",(fid,oid,rid))
            return {'ok':True,'message':'Tersinkron ke Drive dan Sheets'}
        except Exception as e:
            with db() as c: c.execute("UPDATE records SET sync_state='ERROR',sync_error=? WHERE id=?",(str(e)[:500],rid))
            return {'ok':False,'message':'Tersimpan lokal; sinkron Google gagal. Officer dapat Coba sinkron ulang.'}

from app.core import clean,validate,parse_ocr,plate,pw_hash,pw_check

def sample():
    return clean(dict(pabrik='PKS CONTOH',no_nota='CONTOH-001',no_spb='000004',transporter='EXTERNAL',pengemudi='HERYANTO',no_polisi='BK 8731 CK',masuk='2026-10-18T15:05:50',keluar='2026-10-18T15:45:14',bruto=12040,tara=10300,berondolan=0,netto1=1740,potongan_persen=5,potongan_kg=90,netto2=1650,kualitas='A2',harga=3000))
def test_nota_example():
    issues,c=validate(sample(),'BK8731CK')
    assert c['netto1_hitung']==1740 and c['potongan_hitung']==87
    assert c['selisih_potongan']==3 and c['netto2_hitung']==1650
    assert len(issues)==1 and 'Persen' in issues[0]
def test_clean_math():
    b=sample();b.update(potongan_kg=87,netto2=1653)
    assert validate(b,'BK8731CK')[0]==[]
def test_plate_mismatch(): assert any('Pelat' in x for x in validate(sample(),'BM1111ABC')[0])
def test_wrong_netto():
    b=sample();b['netto1']=1741
    assert any('Bruto - tara' in x for x in validate(b)[0])
def test_bad_date():
    b=sample();b['keluar']='abc'
    assert any('Tanggal' in x for x in validate(b)[0])
def test_reversed_time():
    b=sample();b['keluar']='2026-10-18T14:00:00'
    assert any('sebelum' in x for x in validate(b)[0])
def test_ocr_separator():
    assert parse_ocr('Bruto (Kg) : 12,040\nTara (Kg) : 10.300\nPotongan (%) : 5.00')['bruto']==12040
    assert parse_ocr('Potongan (%) : 5.00')['potongan_persen']==5

def test_password():
    h=pw_hash('ExampleStrongPassword!')
    assert pw_check('ExampleStrongPassword!',h) and not pw_check('wrong',h)

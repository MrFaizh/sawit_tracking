"""Retry satu proses: jangan jalankan bersamaan uvicorn. Gunakan tombol officer saat server aktif."""
from app.core import init,db
from app.google_io import sync_record
init()
with db() as c: ids=[r[0] for r in c.execute("SELECT id FROM records WHERE sync_state IN ('PENDING','ERROR') AND status IN ('MENUNGGU_OFFICER','DISETUJUI')")]
for rid in ids: print(rid,sync_record(rid))

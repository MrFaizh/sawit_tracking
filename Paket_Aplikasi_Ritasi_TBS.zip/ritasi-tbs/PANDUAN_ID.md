# RITASI TBS — prototipe mobile web + Google Sheets/Drive

Paket kode awal yang dapat dipasang, bukan APK, bukan layanan yang sudah online.
Antarmuka responsif dibuka dari browser HP; kamera melalui input file capture.
Tidak ada akun Google driver yang diperlukan. Server menggunakan OAuth akun Google admin.
Tidak ada pendaftaran akun bebas; akun dibuat operator melalui CLI di server.

## 1. Alur operasional
1. ADMIN membuat akun DRIVER dan OFFICER dengan supplier_id yang sesuai.
2. DRIVER login HP + sandi awal. Jika memilih mode pelat, formatnya 4 angka pelat + 2/3 HURUF belakang, tanpa kode daerah/spasi (contoh fiktif BM 1234 XYZ -> 1234XYZ). Ini interpretasi permintaan “seri 2/3 digit”; pelat di foto memiliki huruf CK. Format lain perlu penyesuaian.
3. Driver wajib mengganti sandi sebelum dapat scan. Sandi baru minimal 10 karakter dan tidak memuat nomor pelat lengkap. Untuk keamanan lebih tinggi, admin sebaiknya memilih sandi sementara acak, bukan pelat yang dapat dilihat orang.
4. Foto diunggah ke server aplikasi; server melakukan orientasi EXIF, konversi JPG, kompresi, dan OCR Google Vision. Hasil scan disimpan DRAFT di SQLite dan berkas lokal server.
5. Form terisi SEBAGIAN, secara konservatif. Kolom yang belum terbaca harus diisi manual. OCR tidak dijamin membaca layout nota ini dengan sempurna. No nota/PKS/supplier yang ditutup pada foto contoh TIDAK ditebak.
6. Driver melihat foto + teks OCR, melengkapi data, lalu mencentang konfirmasi setiap kolom dan menekan Validasi & kirim.
7. Jika semua validasi lolos -> MENUNGGU_OFFICER: foto olahan + JSON OCR/final dikirim Drive privat; satu baris dikirim tab TRANSAKSI. BELUM dihitung ritasi sah.
8. Jika ada selisih / data kosong -> PERLU_REVIEW: ditahan di server lokal, belum dikirim Drive/Sheets. Officer supplier yang sama dapat melihat dan memperbaiki, menolak atau menyetujui.
9. Officer membandingkan foto manual, mengisi snapshot harga/kg, memberi alasan bila ada koreksi atau pengecualian, kemudian menyetujui. Status DISETUJUI masuk rekap harian. Penolakan tidak dihitung. Transaksi disetujui tidak bisa diedit dari UI prototipe ini.
10. Sinkron yang gagal tidak menghapus transaksi lokal. Officer klik Coba sinkron ulang. Status ERROR/PENDING terlihat. Tidak ada background worker otomatis.

Arti validasi: konsistensi data dan konfirmasi manusia; BUKAN pemeriksaan keaslian nota, bukan pencocokan ke sistem PKS, bukan jaminan anti-pemalsuan.
Semua pengajuan selalu membutuhkan review manusia sebelum dihitung sah.

## 2. Dasar angka foto contoh
Foto yang diberikan terbaca:
- Bruto 12.040 kg, tara 10.300 kg -> netto 1 = 1.740 kg.
- Berondolan 0 kg; potongan 5,00%; berat potongan 90 kg.
- Netto 2 = 1.650 kg; kualitas A2.
- 5% x 1.740 = 87 kg, bukan 90 kg. Selisih potongan 3 kg.
- 1.740 - 90 = 1.650 benar.

JANGAN mengganti 90 menjadi 87 otomatis. PKS mungkin memiliki kebijakan pembulatan, tetapi tidak terbukti dari foto ini. Default toleransi selisih hanya 0,01 kg untuk presisi angka, BUKAN toleransi bisnis. Selisih persen/berat wajib pengecualian officer dengan alasan tertulis. Ketidakcocokan bruto/tara/netto, negatif, tanggal salah, dan netto tidak positif WAJIB diperbaiki sebelum persetujuan; tidak dapat diabaikan dengan alasan.

Berondolan dicatat terpisah, tidak otomatis ditambah/dikurangkan: rumus penanganannya harus dikonfirmasi dengan PKS. Harga, ongkos ritasi driver, pajak, dan potongan lain tidak tercantum di nota contoh. Nilai_Rp hanya netto2 nota x harga/kg input officer, bukan gaji driver, bukan nilai transfer final.

## 3. Persiapan Google (akun ADMIN)
Kebutuhan: Python 3.11+, komputer/server dengan disk persisten, akun Google, project Google Cloud.
1. Buat project Cloud; aktifkan Google Drive API, Google Sheets API, dan Cloud Vision API. Aktifkan billing untuk Vision; biaya mengikuti layanan Google.
2. Konfigurasi OAuth consent screen; buat OAuth client jenis Desktop app. Tambahkan akun admin sebagai test user jika aplikasi masih mode testing. Unduh JSON dan simpan sebagai client_secret.json di direktori paket.
3. Buat API key untuk Cloud Vision, batasi API key hanya untuk Cloud Vision API. Letakkan hanya di .env server, jangan di HTML/repository. Bila memungkinkan batasi juga sumber IP server dan tetapkan kuota/peringatan biaya di Cloud.
4. Jalankan bootstrap_google.py dari komputer admin yang memiliki browser. Browser membuka persetujuan OAuth. Akun Google yang dipilih harus akun pemilik penyimpanan dan sheet.
5. Bootstrap membuat folder RITASI_TBS_PRIVATE, spreadsheet RITASI_TBS_ONLINE dan tab TRANSAKSI, REKAP_HARIAN, KAMUS_DATA; menulis ID ke .env serta refresh credential ke token.json.
6. Jika server berbeda dengan komputer bootstrap, salin token.json dan .env melalui saluran aman ke server. Pastikan GOOGLE_TOKEN_FILE benar. Jangan kirim token melalui chat atau commit Git.

Scope OAuth: drive.file dan spreadsheets. Vision memakai API key backend terpisah.
Folder dan spreadsheet tidak dibuat publik. Link Drive hanya dapat dibuka identitas Google yang diberi akses Drive. Officer tidak perlu diberi akses folder: aplikasi menyediakan preview foto berotorisasi. JANGAN membagikan folder/workbook gabungan ke semua supplier: permission filter pada aplikasi tidak membatasi akses langsung ke Google Sheets/Drive.

OAuth testing/policy dapat membatasi umur refresh token; periksa konfigurasi consent dan kebutuhan publishing/verifikasi sesuai jenis akun sebelum produksi. Jika token dicabut/kedaluwarsa, perbarui otorisasi tanpa membuat spreadsheet baru. Bootstrap selalu membuat dokumen baru; jangan menjalankannya ulang pada sistem aktif tanpa migrasi/cadangan.

## 4. Instalasi dan menjalankan lokal
Terminal macOS/Linux:

    python -m venv .venv
    source .venv/bin/activate
    python -m pip install -r requirements.txt
    cp .env.example .env
    python bootstrap_google.py

Windows PowerShell: aktivasi .venv\Scripts\Activate.ps1, salin contoh dengan Copy-Item .env.example .env.
Isi VISION_API_KEY di .env. Untuk uji localhost HTTP saja, set COOKIE_SECURE=false; untuk akses HP/produksi HTTPS harus true.

Buat user dengan data ASLI milik operasional Anda (angka contoh ini fiktif):

    python manage.py create-user --phone 081234560001 --name "Admin Operasional" --role ADMIN
    python manage.py create-user --phone 081234560002 --name "Officer Supplier A" --role OFFICER --supplier SUP-A
    python manage.py create-user --phone 081234560003 --name "Driver Contoh" --role DRIVER --supplier SUP-A --plate "BM 1234 XYZ" --plate-initial

Dua akun pertama diminta sandi sementara di terminal secara tersembunyi. Akun driver contoh memakai sandi awal 1234XYZ lalu wajib mengganti. Semua sandi bersifat case-sensitive.
Gunakan nomor HP sendiri yang berwenang, jangan menganggap nomor contoh terverifikasi. Tidak ada verifikasi OTP kepemilikan nomor dalam prototipe ini.

Jalankan:

    uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1

Buka browser komputer ke http://127.0.0.1:8000. Login sebagai driver, ganti sandi, login ulang, foto/unggah nota.

Untuk HP: pasang aplikasi pada server di belakang reverse proxy dengan domain HTTPS, disk data persisten, dan COOKIE_SECURE=true. Proxy ke 127.0.0.1:8000. Buka domain dari browser HP. Bila browser mendukung, tambahkan shortcut ke layar utama. Paket ini BUKAN native APK dan BUKAN PWA offline/installable lengkap; tidak memiliki service worker/offline queue.

WAJIB SATU proses / worker aplikasi. Sinkronisasi Google memakai penguncian satu proses + alokasi baris SQLite. Jangan jalankan beberapa instance/replica, jangan memakai filesystem sementara, jangan menjalankan sync_pending.py bersamaan server aktif. Untuk skala lebih besar migrasikan ke PostgreSQL + antrean pekerjaan dan distributed lock.

## 5. Akun dan hak akses
- DRIVER: scan, ubah DRAFT/PERLU_REVIEW milik sendiri, submit, lihat transaksi dan rekap sendiri.
- OFFICER: hanya supplier_id yang ditetapkan admin; lihat foto, angka, OCR; koreksi/approve/reject; input harga/kg; retry sinkron; lihat rekap supplier itu.
- ADMIN: akses lintas supplier lewat UI officer. Pengelolaan akun melalui CLI, belum ada form master user di dashboard.

Reset sandi (akan diminta sandi baru, semua sesi lama dihapus):

    python manage.py reset-password --phone 081234560003

Nonaktifkan akun:

    python manage.py disable-user --phone 081234560003

Satu akun DRIVER dipetakan satu pelat. Pergantian unit/driver memerlukan perubahan master terkontrol di implementasi lanjutan; pada prototipe perbedaan pelat menjadi flag officer. Tidak ada hubungan banyak unit per driver, GPS, notifikasi WhatsApp, atau hak multi-supplier per officer.

## 6. Struktur data Google Sheets
Tab TRANSAKSI memuat 38 kolom; header dan urutan harus tetap. Data ditulis server sebagai RAW agar teks nota tidak dieksekusi sebagai formula.

A ID; B Dibuat_WIB; C Tanggal_Ritasi; D Supplier_ID; E Driver_ID; F Nama_Driver; G No_HP; H No_Polisi; I Pabrik; J No_Nota; K No_SPB; L Transporter; M Pengemudi_Nota; N Masuk_WIB; O Keluar_WIB; P Bruto_Kg; Q Tara_Kg; R Berondolan_Kg; S Netto1_Nota_Kg; T Potongan_Persen; U Potongan_Nota_Kg; V Netto2_Nota_Kg; W Netto1_Hitung_Kg; X Potongan_Hitung_Kg; Y Netto2_Hitung_Kg; Z Selisih_Potongan_Kg; AA Kualitas; AB Harga_Per_Kg; AC Nilai_Rp; AD Status; AE Temuan_Validasi; AF Alasan_Koreksi; AG Officer_ID; AH Diperiksa_WIB; AI Foto_Drive_URL; AJ SHA256_Foto; AK OCR_JSON_Drive_URL; AL OCR_vs_Final_JSON.

Perhitungan server:
- W = P - Q.
- X = S x T / 100.
- Y = S - U.
- Z = U - X.
- AC = V x AB (kosong bila harga belum diisi).
- Tanggal_Ritasi = tanggal keluar nota dalam WIB, bukan tanggal scan.
- Rekap dihitung per tanggal + supplier + driver. Ritasi = jumlah nota DISETUJUI, netto = jumlah V, nilai = jumlah AC. Tidak ada nomor ritasi urutan tetap; jumlah ritasi berasal dari nota unik yang disetujui.

Tab REKAP_HARIAN pada bootstrap menggunakan QUERY otomatis; locale Google workbook diatur en_US untuk konsistensi pemisah formula. Waktu tetap Asia/Jakarta.
Workbook Excel pendamping hanya template terstruktur; tidak terhubung ke server/Google. Rekap Excel memakai COUNTIFS/SUMIFS setelah kolom tanggal/supplier/driver diisi. Contoh nota ada di tab CONTOH_VALIDASI, TIDAK dimasukkan sebagai transaksi sungguhan.

PENTING: Jangan sort/hapus/sisip/append baris tab TRANSAKSI secara manual. Baris dipesan oleh SQLite agar retry menulis ke baris sama dan tidak menggandakan transaksi. Gunakan filter view atau salinan tab untuk analisis. Jangan mengedit angka/status langsung di Google Sheets karena sumber kebenaran prototipe adalah database aplikasi. Jangan menghubungkan dua instalasi/database ke sheet yang sama. Restore DB dan sheet harus konsisten.

## 7. Validasi dan audit
- Kolom wajib: identitas PKS/no nota/SPB/transporter/pengemudi/pelat, tanggal masuk/keluar, kualitas, semua angka berat/potongan. Harga wajib saat approve.
- Input angka form tanpa pemisah ribuan: 12040, 10300, 1740, 5, 90, 1650. OCR mendukung sebagian format ribuan titik/koma; jangan menganggap pembacaan ambigu selalu benar.
- No nota + PKS unik per supplier untuk nota aktif/pending/disetujui. Foto dengan SHA256 sama juga dicegah ketika driver submit ke supplier yang sama. Ini bukan deteksi dokumen mirip/rephotograph atau fraud lintas supplier.
- Pengecekan pelat akun, aritmetika, non-negatif, potongan 0–100%, urutan jam, tanggal format ISO.
- Field OCR yang berhasil diekstrak dibandingkan final dan direkam di AL. Teks OCR dan respons Vision mentah disimpan di JSON Drive. Semua field tetap wajib pemeriksaan manusia; tidak ada bukti algoritmik bahwa angka yang diketik identik dengan foto.
- Officer tidak bisa mengabaikan kesalahan aritmetika inti; pengecualian hanya persen/kg dan perbedaan pelat dengan alasan minimal 15 karakter.
- Dokumen yang ditutup/blur/tidak lengkap harus difoto ulang, bukan diberi angka perkiraan.
- Audit SQLite menyimpan aktor/waktu/login/submit/koreksi/approve/reject. Belum ada ekspor audit UI atau log immutable.
- Foto yang disimpan adalah JPEG hasil orientasi/kompresi; SHA256 mengacu ke JPEG itu. EXIF tidak dipertahankan; bukan preservasi bukti forensik asli.

## 8. Sinkron dan batasan keandalan
Status lokal tetap tersimpan bila internet Google terputus. Tombol retry tersedia untuk officer/admin. Drive dicari dengan appProperties ID transaksi + jenis berkas untuk mengurangi unggah ulang; Sheets menulis ke baris tetap. Ini bukan transaksi atomik lintas SQLite/Drive/Sheets dan bukan jaminan exactly-once: timeout API sangat jarang masih dapat membuat berkas Drive ganda, sehingga butuh rekonsiliasi operasional.

Status Google dapat tertinggal sampai retry sukses. Rekap UI berasal dari DB lokal yang sudah disetujui, sedangkan Google hanya mencerminkan sinkron terakhir. Jangan menganggap status lokal dan sheet selalu sama ketika ada ERROR. Penolakan nota yang pernah terkirim diperbarui statusnya di sheet; JSON Drive untuk nota ditolak tidak diregenerasi dan tetap snapshot sinkron sebelumnya. Lihat audit lokal untuk kejadian penolakan final.

## 9. Keamanan dan persiapan produksi
- Sandi disimpan sebagai hash scrypt bersalt; tidak plaintext. Token sesi acak disimpan dalam cookie HttpOnly, Secure (HTTPS), SameSite Strict; DB menyimpan hash token, kedaluwarsa default 8 jam. Perubahan sandi mencabut semua sesi.
- Lima kegagalan login per nomor HP -> jeda 15 menit. Tambahkan rate limit global/per-IP di reverse proxy, pemantauan, proteksi brute force/distributed attack; kontrol di aplikasi saja tidak cukup.
- Semua mutasi API memerlukan header X-TBS-Client; tidak mengizinkan CORS. Jangan menambahkan wildcard CORS atau membagikan cookie.
- Foto mengandung data pribadi/komersial dan dikirim ke Google Vision untuk OCR. Dapatkan kewenangan/persetujuan operasional, tentukan retensi dan hak akses.
- Simpan .env, token, OAuth secret, SQLite, backups dan foto di lokasi berizin ketat/terenkripsi; jangan expose direktori data lewat web.
- Backup konsisten SQLite melalui SQLite backup API, foto dan konfigurasi; jangan asal menyalin berkas DB aktif tanpa WAL. Tetapkan kebijakan hapus draft/foto lama. Belum ada auto-retention/backup dalam paket.
- Gunakan HTTPS, firewall, pembaruan dependency, uji beban, uji restore, observabilitas dan audit hak akses sebelum produksi.
- Untuk operasi besar/risiko tinggi, gunakan identity provider dengan OTP/MFA dan database terpusat, bukan sandi berdasarkan pelat.

## 10. Tes
    python -m pytest -q

8 tes unit disertakan: contoh nota, hitungan sesuai, beda pelat, netto salah, tanggal salah, jam terbalik, separator OCR, hash sandi. Berkas HASIL_UJI.txt menjelaskan pengujian yang benar-benar dijalankan saat paket dibuat.
Pengujian integrasi login HTTP, kamera perangkat, Google OAuth, Vision, Drive, Sheets, retry dan deployment HTTPS HARUS dilakukan di akun/lingkungan Anda. Paket ini belum diuji end-to-end pada layanan Google.

Checklist penerimaan:
[ ] Buat akun test; sandi awal wajib diganti; akun nonaktif tidak dapat masuk.
[ ] Driver A tidak dapat membuka foto/transaksi Driver B.
[ ] Officer supplier A tidak dapat membuka transaksi supplier B melalui API.
[ ] Foto contoh menghasilkan PERLU_REVIEW atas 87 vs 90, tidak masuk rekap sah.
[ ] Officer input alasan pembulatan yang telah dikonfirmasi PKS -> approved dengan angka nota yang sah.
[ ] Putus akses Google saat submit -> data lokal tetap ada; retry tidak menggandakan baris sheet.
[ ] Catat 2 nota unik driver sama -> 2 ritasi pada tanggal keluar nota.
[ ] Nota ditolak tidak menambah ritasi/nilai.
[ ] Jangan deploy publik sebelum uji keamanan akses, cadangan, token OAuth dan biaya Vision.

## 11. Sumber teknis
Google Cloud Vision OCR: https://docs.cloud.google.com/vision/docs/ocr
Vision document text: https://cloud.google.com/vision/docs/handwriting
Google Sheets API: https://developers.google.com/workspace/sheets/api
Google Drive API: https://developers.google.com/workspace/drive/api

Tidak diperlukan Google Apps Script untuk arsitektur paket ini. Backend Python dipilih agar validasi, sandi scrypt, pemisahan peran dan antrean sinkron lokal berada di server, bukan di worksheet atau kode browser.

import argparse, getpass, uuid, re
from app.core import *
p=argparse.ArgumentParser();p.add_argument('command',choices=['create-user','reset-password','disable-user']);p.add_argument('--phone',required=True);p.add_argument('--name');p.add_argument('--role',choices=['ADMIN','OFFICER','DRIVER']);p.add_argument('--supplier',default='');p.add_argument('--plate',default='');p.add_argument('--plate-initial',action='store_true',help='Sandi awal 4 angka + 2/3 huruf belakang pelat; wajib ganti')
a=p.parse_args();init();hp=phone(a.phone)
if a.command=='disable-user':
    with db() as c:
        u=c.execute('SELECT id FROM users WHERE phone=?',(hp,)).fetchone()
        if not u: raise SystemExit('HP tidak ditemukan')
        c.execute('UPDATE users SET active=0 WHERE id=?',(u['id'],));c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],));audit(c,'CLI_ADMIN','DISABLE_USER',u['id'])
else:
    if a.command=='create-user' and (not a.name or not a.role or (a.role!='ADMIN' and not a.supplier)): raise SystemExit('Isi --name --role --supplier (supplier boleh kosong untuk ADMIN)')
    if a.plate_initial:
        if a.role!='DRIVER': raise SystemExit('--plate-initial hanya untuk create-user DRIVER')
        m=re.fullmatch(r'[A-Z]{1,2}(\d{4}[A-Z]{2,3})',plate(a.plate))
        if not m: raise SystemExit('Pelat harus: kode depan + 4 angka + 2/3 huruf belakang')
        password=m.group(1); must=1
    else:
        password=getpass.getpass('Sandi sementara baru (min 10 karakter): ')
        if len(password)<10: raise SystemExit('Minimal 10 karakter')
        must=1
    with db() as c:
        if a.command=='create-user':
            if a.role=='DRIVER' and not re.fullmatch(r'[A-Z]{1,2}\d{4}[A-Z]{2,3}',plate(a.plate)): raise SystemExit('Isi --plate lengkap')
            uid=str(uuid.uuid4());c.execute('INSERT INTO users(id,phone,name,role,supplier,plate,password,must_change) VALUES(?,?,?,?,?,?,?,?)',(uid,hp,a.name,a.role,a.supplier,plate(a.plate),pw_hash(password),must));audit(c,'CLI_ADMIN','CREATE_USER',uid)
        else:
            u=c.execute('SELECT id FROM users WHERE phone=?',(hp,)).fetchone()
            if not u: raise SystemExit('HP tidak ditemukan')
            c.execute('UPDATE users SET password=?,must_change=1 WHERE id=?',(pw_hash(password),u['id']));c.execute('DELETE FROM sessions WHERE user_id=?',(u['id'],));audit(c,'CLI_ADMIN','RESET_PASSWORD',u['id'])
print('Selesai. Sandi tidak dicetak dan tidak dikirim ke Google Sheets.')
